from transform import random_rot_flip, random_rotate

import h5py
import numpy as np
import os
from scipy.ndimage.interpolation import zoom
import torch
from torch.utils.data import Dataset
import random
from detectron2.structures import BitMasks, Instances


class ACDCDataset(Dataset):
    def __init__(self, name, root, mode, size=None, id_path=None):
        self.name = name
        self.root = root
        self.mode = mode
        self.size = size

        if mode == 'train':
            with open(id_path, 'r') as f:
                self.ids = f.read().splitlines()
        else:
            with open('splits/%s/valtest.txt' % name, 'r') as f:
                self.ids = f.read().splitlines()

    def __getitem__(self, item):
        id = self.ids[item]
        sample = h5py.File(os.path.join(self.root, id), 'r')
        img = sample['image'][:]
        mask = sample['label'][:]

        if self.mode == 'val':
            return torch.from_numpy(img).float(), torch.from_numpy(mask).long()

        if random.random() > 0.5:
            img, mask = random_rot_flip(img, mask)
        elif random.random() > 0.5:
            img, mask = random_rotate(img, mask)

        x, y = img.shape
        img = zoom(img, (self.size / x, self.size / y), order=0)
        mask = zoom(mask, (self.size / x, self.size / y), order=0)  ### (224, 224)

        #################  制作dataset_dict，区分各个实例  ##########################
        ##### dataset_dict['spatial_query']['gt_masks']
        ##### dataset_dict['spatial_query']['rand_shape']
        ##### dataset_dict['instance']
        dataset_dict = copy.deepcopy(dataset_dict)
        dataset_dict["image"] = image

        instances = Instances(image_shape)
        instances.gt_classes = torch.tensor(classes, dtype=torch.int64)

        if len(masks) == 0:
            instances.gt_masks = torch.zeros((0, pan_seg_gt.shape[-2], pan_seg_gt.shape[-1]))
        else:
            masks = BitMasks(
                torch.stack([torch.from_numpy(np.ascontiguousarray(x.copy())) for x in masks])
            )
            instances.gt_masks = masks.tensor

        dataset_dict["instances"] = instances
        dataset_dict['spatial_query']['gt_masks'] = instances.gt_masks
        dataset_dict['spatial_query']['rand_shape'] = BitMasks(torch.stack([torch.from_numpy(dataset_dict["final_ref_imgs"][idx][1]) for idx in range(len(dataset_dict["final_ref_imgs"]))])).tensor

        return dataset_dict

    def __len__(self):
        return len(self.ids)
