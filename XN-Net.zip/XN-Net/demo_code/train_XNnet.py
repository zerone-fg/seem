import torch
from torch.utils.tensorboard import SummaryWriter
import argparse
from xdecoder.BaseModel import BaseModel
from xdecoder import build_model
from utils.distributed import init_distributed
from utils.arguments import load_opt_from_config_files
from utils.constants import ACDC_CLASSES
from dataset.ACDC.acdc import ACDCDataset
from utils.util import AverageMeter, init_log
from torch.utils.data import DataLoader
import yaml
import numpy as np
from torch.optim import AdamW
import os
import logging


def main():
    parser = argparse.ArgumentParser('SEEM Demo', add_help=False)
    parser.add_argument('--conf_files', default="configs/seem/seem_focall_lang.yaml", metavar="FILE",
                        help='path to config file', )
    parser.add_argument('--yaml_file', default="configs/ACDC/acdc.yaml")
    parser.add_argument('--save_path', default="./save_acdc_xnnet/")

    args = parser.parse_args()

    opt = load_opt_from_config_files(args.conf_files)
    opt = init_distributed(opt)

    if 'focalt' in args.conf_files:
        pretrained_pth = os.path.join("seem_focalt_v2.pt")
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focalt_v2.pt"))
    elif 'focal' in args.conf_files:
        pretrained_pth = "/data1/seem_focall_v1.pt"
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focall_v1.pt"))

    ##############  模型参数定义  ###############################################################################
    logger = init_log('global', logging.INFO)
    logger.propagate = 0

    model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).cuda()
    model.model.sem_seg_head.predictor.lang_encoder.get_text_embeddings(ACDC_CLASSES + ["background"],
                                                                        is_eval=False)

    model.model.task_switch['spatial'] = True
    model.model.task_switch['visual'] = False
    model.model.task_switch['grounding'] = False
    model.model.task_switch['audio'] = False

    optimizer = AdamW([param for name, param in model.named_parameters()], 2e-5, weight_decay=1e-4)

    writer = SummaryWriter(args.save_path)

    previous_best = 0.0
    epoch = -1

    cfg = yaml.load(open(args.yaml_file, "r"), Loader=yaml.Loader)

    ################# dataloader部分  ########################
    trainset = ACDCDataset(cfg['dataset'], cfg['data_root'], 'train_l',
                             cfg['crop_size'], args.labeled_id_path, nsample=len(trainset_u.ids))
    valset = ACDCDataset(cfg['dataset'], cfg['data_root'], 'val')

    trainloader = DataLoader(trainset, batch_size=cfg['batch_size'],
                               num_workers=0, drop_last=True)
    valloader = DataLoader(valset, batch_size=1, num_workers=0,
                           drop_last=False)

    if os.path.exists(os.path.join(args.save_path, 'best.pth')):
        checkpoint = torch.load(os.path.join(args.save_path, 'best.pth'))
        model.load_state_dict(checkpoint['model'])

    for epoch in range(epoch + 1, cfg['epochs']):
        logger.info('===========> Epoch: {:}, LR: {:.5f}, Previous best: {:.2f}'.format(
                epoch, optimizer.param_groups[0]['lr'], previous_best))

        total_loss = AverageMeter()

        for i, data in enumerate(trainloader):
            model.train()

            loss = model.model(data)
            losses = sum(loss.values()) / 6
            losses.backward()
            print(i)
            if (i + 1) % 6 == 0:
                optimizer.step()  # 根据累计到batch_size个梯度，进行网络参数更新
                optimizer.zero_grad()  # 梯度清0

            iters = epoch * len(trainloader) + i

            total_loss.update(losses.item())

            writer.add_scalar('train/loss_all', losses.item(), iters)

            if ((i+1) % 6) == 0:
                logger.info(
                    'Iters: {:}, Total loss: {:.3f}'.format(i, total_loss.avg))

            if ((i + 1) % 1000) == 0:
                model.eval()
                with torch.no_grad():
                    iou_arr = np.zeros(30)
                    count_arr = np.zeros(30)

                    for idx, input in enumerate(valloader):
                        pred = model(input, mode='interactive')
                        tar_class = input[0]["groundings"]["hash"]
                        for i, iou_ in enumerate(pred):
                            max_iou = iou_['mask_iou'][-1]

                            iou_arr[tar_class[i]] += max_iou
                            count_arr[tar_class[i]] += 1

                    miou = iou_arr / (count_arr + 1e-7)
                    miou = miou[np.nonzero(miou)].mean()
                    print("segment iou is:{}".format(miou))

                    if miou > previous_best:
                        previous_best = miou
                        checkpoint = {
                            'model': model.state_dict(),
                            'optimizer': optimizer.state_dict(),
                            'epoch': epoch,
                            'previous_best': previous_best,
                        }
                        torch.save(checkpoint, os.path.join(args.save_path, 'best.pth'))



if __name__ == "__main__":
    main()



