try:
    # ignore ShapelyDeprecationWarning from fvcore
    from shapely.errors import ShapelyDeprecationWarning
    import warnings
    warnings.filterwarnings('ignore', category=ShapelyDeprecationWarning)
except:
    pass

import copy
import itertools
import logging
import os

from collections import OrderedDict
from typing import Any, Dict, List, Set

import torch
from torch.utils.tensorboard import SummaryWriter
import detectron2.utils.comm as comm
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.config import get_cfg
from detectron2.data import MetadataCatalog, build_detection_train_loader, build_detection_test_loader
from detectron2.engine import (
    DefaultTrainer,
    default_argument_parser,
    default_setup,
    launch,
)
from detectron2.evaluation import (
    COCOEvaluator,
    COCOPanopticEvaluator,
    DatasetEvaluators,
    SemSegEvaluator,
    verify_results,
)
from detectron2.projects.deeplab import add_deeplab_config, build_lr_scheduler
from detectron2.solver.build import maybe_add_gradient_clipping
from detectron2.utils.logger import setup_logger
import argparse
# MaskFormer
from dataset.maskfromer_panoptic_dataset_mapper import MaskFormerPanopticDatasetMapper
from dataset.mask_former_semantic_dataset_mapper import MaskFormerSemanticDatasetMapper
from configs.config import add_maskformer2_config
from dataset.register_coco_panptic_anno import register_all_coco_panoptic_annos_sem_seg

from xdecoder.BaseModel import BaseModel
from xdecoder import build_model
from utils.distributed import init_distributed
from utils.arguments import load_opt_from_config_files
from torch.optim import SGD
from utils.constants import COCO_PANOPTIC_CLASSES
from utils.util import count_params, init_log, AverageMeter
import logging
import yaml
from evaluate import evaluate
from classes import CLASSES
from detectron2.engine import DefaultTrainer
from torch.optim import AdamW

CUDA_VISIBLE_DEVICES=1

#######  backbone and decoder using pretrained ckpt and both without freezing  #####
def setup(args):
    """
    Create configs and perform basic setups.
    """
    cfg = get_cfg()
    # for poly lr schedule
    add_deeplab_config(cfg)
    add_maskformer2_config(cfg)
    cfg.merge_from_file(
        "/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/configs/maskformer2_R50_bs16_50ep.yaml")
    # cfg.merge_from_list(args.opts)
    cfg.freeze()
    default_setup(cfg, args)
    # Setup logger for "mask_former" module
    setup_logger(output=cfg.OUTPUT_DIR, distributed_rank=comm.get_rank(), name="mask2former")
    return cfg

def main():
    parser = argparse.ArgumentParser('SEEM Demo', add_help=False)
    parser.add_argument('--conf_files', default="configs/seem/seem_focall_lang.yaml", metavar="FILE",
                        help='path to config file', )
    parser.add_argument('--yaml_file', default="configs/coco.yaml")
    parser.add_argument('--save_path', default="./save_intial_back_freeze_none/")
    args = parser.parse_args()

    #############  读取模型文件并配置  ######################
    opt = load_opt_from_config_files(args.conf_files)
    opt = init_distributed(opt)

    if 'focalt' in args.conf_files:
        pretrained_pth = os.path.join("seem_focalt_v2.pt")
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focalt_v2.pt"))
    elif 'focal' in args.conf_files:
        pretrained_pth = "/data1/seem_focall_v1.pt"
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focall_v1.pt"))

    model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).cuda()
    model.model.sem_seg_head.predictor.lang_encoder.get_text_embeddings(COCO_PANOPTIC_CLASSES + ["background"],
                                                                        is_eval=True)
    ### 固定backbone,decoder初始化 ####


    ##########  设置训练模式，通用分割任务  ############################################################
    # model.task_switch['visual'] = False
    model.model.task_switch['spatial'] = False
    model.model.task_switch['visual'] = False
    model.model.task_switch['grounding'] = True
    model.model.task_switch['audio'] = False

    #############  读取训练文件并配置  ####################
    cfg_yaml = yaml.load(open(args.yaml_file, "r"), Loader=yaml.Loader)
    # optimizer = SGD([param for name, param in model.named_parameters()], cfg_yaml['lr'], momentum=0.9, weight_decay=1e-4)
    optimizer = AdamW([param for name, param in model.named_parameters()], 2e-5, weight_decay=1e-4)

    logger = init_log('global', logging.INFO)
    writer = SummaryWriter(args.save_path)
    logger.propagate = 0

    previous_best = 0.0
    epoch = -1
    rank = 0

    cfg = setup(args)

    register_all_coco_panoptic_annos_sem_seg()

    mapper = MaskFormerPanopticDatasetMapper(cfg, True)
    train_loader = build_detection_train_loader(cfg, mapper=mapper)

    val_dataset_name = "coco_2017_val_panoptic_with_sem_seg"
    val_loader = build_detection_test_loader(cfg, mapper=mapper, dataset_name=val_dataset_name)

    evaluator_list = []
    evaluator_type = MetadataCatalog.get(val_dataset_name).evaluator_type
    output_folder = os.path.join(cfg.OUTPUT_DIR, "inference")

    if evaluator_type == "coco_panoptic_seg" and cfg.MODEL.MASK_FORMER.TEST.SEMANTIC_ON:
        evaluator_list.append(SemSegEvaluator(val_dataset_name, distributed=True, output_dir=output_folder))
    evaluator = evaluator_list[0]

    total_iters = len(train_loader) * 30

    if os.path.exists(os.path.join(args.save_path, 'latest.pth')):
        checkpoint = torch.load(os.path.join(args.save_path, 'latest.pth'))
        model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        epoch = checkpoint['epoch']
        previous_best = checkpoint['previous_best']

    for epoch in range(epoch + 1, cfg_yaml['epochs']):
        logger.info('===========> Epoch: {:}, LR: {:.5f}, Previous best: {:.2f}'.format(
                epoch, optimizer.param_groups[0]['lr'], previous_best))

        total_loss = AverageMeter()
        for i, data in enumerate(train_loader):
        #     model.train()
        #
        #     loss = model.model(data)
        #     losses = sum(loss.values())
        #
        #     optimizer.zero_grad()
        #     losses.backward()
        #     optimizer.step()
        #
        #     iters = epoch * len(train_loader) + i
        #
        #     # optimizer.param_groups[0]["lr"] = lr
        #     # optimizer.param_groups[1]["lr"] = lr * cfg['lr_multi']
        #
        #     total_loss.update(losses.item())
        #
        #     writer.add_scalar('train/loss_all', losses.item(), iters)
        #
        #     if (i % (len(train_loader) // 8) == 0):
        #         logger.info(
        #             'Iters: {:}, Total loss: {:.3f}'.format(i, total_loss.avg))

            if (i % 5000) == 0:
                model.eval()
                res = DefaultTrainer.test(cfg, model, evaluator)
                mIOU = res["sem_seg"]["mIoU"]

                writer.add_scalar('eval/mIoU', mIOU, epoch)

                is_best = mIOU > previous_best
                previous_best = max(mIOU, previous_best)
                if rank == 0:
                    checkpoint = {
                        'model': model.state_dict(),
                        'optimizer': optimizer.state_dict(),
                        'epoch': epoch,
                        'previous_best': previous_best,
                    }
                    torch.save(checkpoint, os.path.join(args.save_path, 'latest.pth'))
                    if is_best:
                        torch.save(checkpoint, os.path.join(args.save_path, 'best.pth'))
            if i > total_iters:
                break


if __name__ == "__main__":
    main()



