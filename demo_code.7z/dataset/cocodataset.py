from dataset.transform1 import *

from copy import deepcopy
import math
import numpy as np
import os
import random

from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms


class cocoDataset(Dataset):
    def __init__(self, name, root, mode, size=None):
        self.name = name
        self.root = root
        self.mode = mode
        self.size = size

        if mode == 'train':
            with open('/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/dataset/split/%s/train.txt' % name, 'r') as f:
                self.ids = f.read().splitlines()
        else:
            with open('/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/dataset/split/%s/val.txt' % name, 'r') as f:
                self.ids = f.read().splitlines()

    def __getitem__(self, item):
        id = self.ids[item]
        img = Image.open(os.path.join(self.root, 'images', id.split(' ')[0])).convert('RGB')
        # mask = Image.fromarray(np.array(Image.open(os.path.join(self.root, id.split(' ')[1]))))
        if self.mode == 'train':
            mask_path = os.path.join('/data1/SegmentationClass/', id.split(' ')[1].split('/')[1])
        else:
            mask_path = os.path.join('/data1/SegmentationClass_val/', id.split(' ')[1].split('/')[1])
        mask = Image.fromarray(np.array(Image.open(mask_path)))

        if self.mode == 'val':
            img, mask = val_normalize(img, mask)
            height, width = img.shape[1:]
            data = {"image": img, "height": height, "width": width, "mask": mask, "id": os.path.join(self.root, 'images', id.split(' ')[0])}
            return data

        img, mask = resize(img, mask, (0.5, 2.0))
        ignore_value = 255
        img, mask = crop(img, mask, self.size, ignore_value)
        img, mask = hflip(img, mask, p=0.5)
        img, mask = val_normalize(img, mask)

        # width, height = img.shape[1:]
        height, width = img.shape[1:]
        data = {"image": img, "height": height, "width": width, "mask": mask}

        return data

    def __len__(self):
        return len(self.ids)