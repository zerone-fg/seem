import os
data_path_train = "/data1/SegmentationClass/"
data_path_val = "/data1/SegmentationClass_val/"

train_txt = open("/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/dataset/split/coco/train.txt", "w")
val_txt = open("/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/dataset/split/coco/val.txt", "w")

train_dir = os.path.join(data_path_train)
val_dir = os.path.join(data_path_val)

i= 0
for img in os.listdir(train_dir):
    line = "train2017/" + img.replace("png", "jpg") + " " + "masks/" + img
    train_txt.write(line + "\n")
    i+=1

train_txt.close()
print(i)
i=0

for img in os.listdir(val_dir):
    line = "val2017/" + img.replace("png", "jpg") + " " + "masks/" + img
    val_txt.write(line + "\n")
    i+=1
print(i)
val_txt.close()