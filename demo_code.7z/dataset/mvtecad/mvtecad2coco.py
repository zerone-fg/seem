#!/usr/bin/env python3

import datetime
import json
import os
import re
import fnmatch
from PIL import Image
import numpy as np
from pycococreatortools import pycococreatortools

ROOT_DIR = '/data1/mvetad_deal/'
IMAGE_DIR = os.path.join(ROOT_DIR, "val")
ANNOTATION_DIR = os.path.join(ROOT_DIR, "val_anno")

INFO = {
    "description": "mvtead Dataset",
    "url": "https://github.com/waspinator/pycococreator",
    "version": "0.1.0",
    "year": 2023,
    "contributor": "zerone",
    "date_created": datetime.datetime.utcnow().isoformat(' ')
}

LICENSES = [
    {
        "id": 1,
        "name": "Attribution-NonCommercial-ShareAlike License",
        "url": "http://creativecommons.org/licenses/by-nc-sa/2.0/"
    }
]

CATEGORIES = [
    {
        'id': 0,
        'name': 'good bottle',
        'supercategory': 'normal',
    },
    {
        'id': 1,
        'name': 'damaged bottle',
        'supercategory': 'abnormal',
    },
    {
        'id': 2,
        'name': 'good cable',
        'supercategory': 'normal',
    },
    {
        'id': 3,
        'name': 'damaged cable',
        'supercategory': 'abnormal',
    },
    {
        'id': 4,
        'name': 'good capsule',
        'supercategory': 'normal',
    },
    {
        'id': 5,
        'name': 'damaged capsule',
        'supercategory': 'abnormal',
    },
    {
        'id': 6,
        'name': 'good carpet',
        'supercategory': 'normal',
    },
    {
        'id': 7,
        'name': 'damaged carpet',
        'supercategory': 'abnormal',
    },
    {
        'id': 8,
        'name': 'good grid',
        'supercategory': 'normal',
    },
    {
        'id': 9,
        'name': 'damaged grid',
        'supercategory': 'abnormal',
    },
    {
        'id': 10,
        'name': 'good hazelnut',
        'supercategory': 'normal',
    },
    {
        'id': 11,
        'name': 'damaged hazelnut',
        'supercategory': 'abnormal',
    },
    {
        'id': 12,
        'name': 'good leather',
        'supercategory': 'normal',
    },
    {
        'id': 13,
        'name': 'damaged leather',
        'supercategory': 'abnormal',
    },
    {
        'id': 14,
        'name': 'good metal_nut',
        'supercategory': 'normal',
    },
    {
        'id': 15,
        'name': 'damaged metal_nut',
        'supercategory': 'abnormal',
    },
    {
        'id': 16,
        'name': 'good pill',
        'supercategory': 'normal',
    },
    {
        'id': 17,
        'name': 'damaged pill',
        'supercategory': 'abnormal',
    },
    {
        'id': 18,
        'name': 'good screw',
        'supercategory': 'normal',
    },
    {
        'id': 19,
        'name': 'damaged screw',
        'supercategory': 'abnormal',
    },
    {
        'id': 20,
        'name': 'good tile',
        'supercategory': 'normal',
    },
    {
        'id': 21,
        'name': 'damaged tile',
        'supercategory': 'abnormal',
    },
    {
        'id': 22,
        'name': 'good toothbrush',
        'supercategory': 'normal',
    },
    {
        'id': 23,
        'name': 'damaged toothbrush',
        'supercategory': 'abnormal',
    },
    {
        'id': 24,
        'name': 'good transistor',
        'supercategory': 'normal',
    },
    {
        'id': 25,
        'name': 'damaged transistor',
        'supercategory': 'abnormal',
    },
    {
        'id': 26,
        'name': 'good wood',
        'supercategory': 'normal',
    },
    {
        'id': 27,
        'name': 'damaged wood',
        'supercategory': 'abnormal',
    },
    {
        'id': 28,
        'name': 'good zipper',
        'supercategory': 'normal',
    },
    {
        'id': 29,
        'name': 'damaged zipper',
        'supercategory': 'abnormal',
    },
]


def filter_for_jpeg(root, files):
    file_types = ['*.jpeg', '*.png']
    file_types = r'|'.join([fnmatch.translate(x) for x in file_types])
    files = [os.path.join(root, f) for f in files]
    files = [f for f in files if re.match(file_types, f)]

    return files


def filter_for_annotations(root, files, image_filename):
    # file_types = ['*.png']
    # file_types = r'|'.join([fnmatch.translate(x) for x in file_types])
    # basename_no_extension = os.path.splitext(os.path.basename(image_filename))[0]
    # file_name_prefix = basename_no_extension + '.*'
    # files = [os.path.join(root, f) for f in files]
    # files = [f for f in files if re.match(file_types, f)]
    # # files = [f for f in files if re.match(file_name_prefix, os.path.splitext(os.path.basename(f))[0])]
    ###### 根据image_file_name找到对应的annotation  ######
    img_name = image_filename.split('/')[-1]
    file_prefix = image_filename[:-len(img_name)].replace('val', 'val_anno')
    anno_name = img_name
    files = [file_prefix + anno_name]

    return files


def main():
    coco_output = {
        "info": INFO,
        "licenses": LICENSES,
        "categories": CATEGORIES,
        "images": [],
        "annotations": []
    }

    image_id = 1
    segmentation_id = 1

    # filter for jpeg images
    for root, _, files in os.walk(IMAGE_DIR):
        image_files = filter_for_jpeg(root, files)

        # go through each image
        for image_filename in image_files:
            image = Image.open(image_filename)
            image_info = pycococreatortools.create_image_info(
                image_id, os.path.basename(image_filename), image.size)
            coco_output["images"].append(image_info)

            # filter for associated png annotations
            for root, _, files in os.walk(ANNOTATION_DIR):
                annotation_files = filter_for_annotations(root, files, image_filename)
                # go through each associated annotation
                for annotation_filename in annotation_files:

                    print(annotation_filename)
                    #### 根据标注的名称确定相应的类别
                    anno_name_split = annotation_filename.split('/')[-1]
                    object_name = anno_name_split.split('_')[0]
                    if object_name == 'metal':
                        object_name = 'metal_nut'
                        state_name = 'good' if anno_name_split.split('_')[2] == 'good' else 'damaged'
                    else:
                        state_name = 'good' if anno_name_split.split('_')[1] == 'good' else 'damaged'
                    print(state_name + ' ' + object_name)
                    class_id = [x['id'] for x in CATEGORIES if x['name'] == (state_name + ' ' + object_name)][0]
                    # class_id = [x['id'] for x in CATEGORIES if x['name'] in annotation_filename][0]

                    category_info = {'id': class_id, 'is_crowd': 'crowd' in image_filename}
                    #### annotation可能不存在，直接用全零代替 #####
                    if state_name == 'good':
                        binary_mask = np.zeros(image.size).astype(np.uint8)
                        #### 保存下全黑的图像 ####
                        im = Image.fromarray(binary_mask)
                        im.save(annotation_filename)
                    else:
                        binary_mask = np.asarray(Image.open(annotation_filename)
                                             .convert('1')).astype(np.uint8)

                    annotation_info = pycococreatortools.create_annotation_info(
                        segmentation_id, image_id, category_info, binary_mask,
                        image.size, tolerance=2)

                    if annotation_info is not None:
                        coco_output["annotations"].append(annotation_info)
                        print(1)

                    segmentation_id = segmentation_id + 1

            image_id = image_id + 1

    with open('{}/instances_mvtecad_val2023.json'.format(ROOT_DIR), 'w') as output_json_file:
        json.dump(coco_output, output_json_file)


if __name__ == "__main__":
    main()
