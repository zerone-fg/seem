# Copyright (c) Facebook, Inc. and its affiliates.
import copy

import numpy as np
import torch
from torch.nn import functional as F
from PIL import Image
from detectron2.config import configurable
from detectron2.data import detection_utils as utils
from detectron2.data import transforms as T
from detectron2.structures import BitMasks, Instances
from collections import defaultdict
from utils.constants import MVTEDAD_CLASS
import cv2
from .mask_former_semantic_dataset_mapper import MaskFormerSemanticDatasetMapper

__all__ = ["askFormerPanopticDatasetMapperTrain"]


class MaskFormerPanopticDatasetMapper(MaskFormerSemanticDatasetMapper):
    """
    A callable which takes a dataset dict in Detectron2 Dataset format,
    and map it into a format used by MaskFormer for panoptic segmentation.

    The callable currently does the following:

    1. Read the image from "file_name"
    2. Applies geometric transforms to the image and annotation
    3. Find and applies suitable cropping to the image and annotation
    4. Prepare image and annotation to Tensors
    """

    @configurable
    def __init__(
        self,
        is_train=True,
        *,
        augmentations,
        image_format,
        ignore_label,
        size_divisibility,
    ):
        """
        NOTE: this interface is experimental.
        Args:
            is_train: for training or inference
            augmentations: a list of augmentations or deterministic transforms to apply
            image_format: an image format supported by :func:`detection_utils.read_image`.
            ignore_label: the label that is ignored to evaluation
            size_divisibility: pad image size to be divisible by this value
        """
        super().__init__(
            is_train,
            augmentations=augmentations,
            image_format=image_format,
            ignore_label=ignore_label,
            size_divisibility=size_divisibility,
        )

    def __call__(self, dataset_dict):
        """
        Args:
            dataset_dict (dict): Metadata of one image, in Detectron2 Dataset format.

        Returns:
            dict: a format that builtin models in detectron2 accept
        """

        dataset_dict = copy.deepcopy(dataset_dict)  # it will be modified by code below
        image = utils.read_image(dataset_dict["file_name"], format=self.img_format)

        ref_imgs = [utils.read_image(dataset_dict["reference_img"][idx][0], format=self.img_format) for idx in range(len(dataset_dict["reference_img"]))]

        utils.check_image_size(dataset_dict, image)

        # semantic segmentation
        if "sem_seg_file_name" in dataset_dict:
            sem_seg_gt = utils.read_image(dataset_dict.pop("sem_seg_file_name")).astype("double")
        else:
            sem_seg_gt = None

        # panoptic segmentation
        if "pan_seg_file_name" in dataset_dict:
            pan_seg_gt = utils.read_image(dataset_dict.pop("pan_seg_file_name"), "L")
            segments_info = dataset_dict["segments_info"]
        else:
            pan_seg_gt = None
            segments_info = None

        if "reference_img" in dataset_dict:
            ref_mask = [utils.read_image(dataset_dict["reference_img"][idx][1], "L") for idx in range(len(dataset_dict["reference_img"]))]

        if pan_seg_gt is None:
            raise ValueError(
                "Cannot find 'pan_seg_file_name' for panoptic segmentation dataset {}.".format(
                    dataset_dict["file_name"]
                )
            )

        dict_add = {'groundings':{}}
        dataset_dict.update(dict_add)

        dict_add = {'spatial_query':{}}
        dataset_dict.update(dict_add)

        dataset_dict['groundings']['texts'] = []
        dataset_dict['groundings']['hash'] = []

        hash_id = []

        for i in range(len(segments_info)):
            cate_id = segments_info[i]['category_id']
            if not segments_info[i]["iscrowd"]:
                dataset_dict['groundings']['texts'].append(MVTEDAD_CLASS[cate_id])
                hash_id.append(cate_id)

        dataset_dict['groundings']['hash'] = np.array(hash_id)

        aug_input = T.AugInput(image, sem_seg=sem_seg_gt)
        aug_input, transforms = T.apply_transform_gens(self.tfm_gens, aug_input)
        image = aug_input.image


        aug_ref_imgs = []
        for idx, ref_img in enumerate(ref_imgs):
            aug_input_1 = T.AugInput(ref_img)
            aug_input_1, transforms_1 = T.apply_transform_gens(self.tfm_gens, aug_input_1)
            ref_img = aug_input_1.image

            ref_img_mask = transforms_1.apply_segmentation(ref_mask[idx])
            ref_img_mask = torch.as_tensor(ref_img_mask.astype("long"))
            ref_img_mask = (ref_img_mask.squeeze(-1) == 255).numpy()

            ref_image = torch.as_tensor(np.ascontiguousarray(ref_img.transpose(2, 0, 1)))
            aug_ref_imgs.append((ref_image, ref_img_mask))

        if sem_seg_gt is not None:
            sem_seg_gt = aug_input.sem_seg

        pan_seg_gt = transforms.apply_segmentation(pan_seg_gt)

        image = torch.as_tensor(np.ascontiguousarray(image.transpose(2, 0, 1)))
        if sem_seg_gt is not None:
            sem_seg_gt = torch.as_tensor(sem_seg_gt.astype("long"))
        pan_seg_gt = torch.as_tensor(pan_seg_gt.astype("long"))

        final_ref_imgs = []
        if self.size_divisibility > 0:
            image_size = (image.shape[-2], image.shape[-1])
            padding_size = [
                0,
                self.size_divisibility - image_size[1],
                0,
                self.size_divisibility - image_size[0],
            ]
            image = F.pad(image, padding_size, value=128).contiguous()
            for (ref_img, ref_img_mask) in aug_ref_imgs:
                ref_img = F.pad(ref_img, padding_size, value=128).contiguous()
                ref_img_mask = F.pad(
                    ref_img_mask, padding_size, value=0
                ).contiguous()

                final_ref_imgs.append((ref_img, ref_img_mask))

            if sem_seg_gt is not None:
                sem_seg_gt = F.pad(sem_seg_gt, padding_size, value=self.ignore_label).contiguous()


            pan_seg_gt = F.pad(
                pan_seg_gt, padding_size, value=0
            ).contiguous()

        else:
            final_ref_imgs = aug_ref_imgs

        image_shape = (image.shape[-2], image.shape[-1])  # h, w

        dataset_dict["image"] = image
        if sem_seg_gt is not None:
            dataset_dict["sem_seg"] = sem_seg_gt.long()

        if "annotations" in dataset_dict:
            raise ValueError("Pemantic segmentation dataset should not have 'annotations'.")

        pan_seg_gt = pan_seg_gt.squeeze(-1)
        pan_seg_gt = pan_seg_gt.numpy()

        instances = Instances(image_shape)
        classes = []
        masks = []
        for segment_info in segments_info:
            class_id = segment_info["category_id"]
            if not segment_info["iscrowd"]:
                classes.append(class_id)
                masks.append(pan_seg_gt == 255)

        classes = np.array(classes)
        instances.gt_classes = torch.tensor(classes, dtype=torch.int64)

        if len(masks) == 0:
            instances.gt_masks = torch.zeros((0, pan_seg_gt.shape[-2], pan_seg_gt.shape[-1]))
        else:
            masks = BitMasks(
                torch.stack([torch.from_numpy(np.ascontiguousarray(x.copy())) for x in masks])
            )
            instances.gt_masks = masks.tensor

        dataset_dict["instances"] = instances
        dataset_dict['groundings']['masks'] = instances.gt_masks
        dataset_dict["final_ref_imgs"] = final_ref_imgs

        dataset_dict['spatial_query']['gt_masks'] = instances.gt_masks
        dataset_dict['spatial_query']['rand_shape'] = BitMasks(torch.stack([torch.from_numpy(dataset_dict["final_ref_imgs"][idx][1]) for idx in range(len(dataset_dict["final_ref_imgs"]))])).tensor
        return dataset_dict

