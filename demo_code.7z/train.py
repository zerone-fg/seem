# --------------------------------------------------------
# SEEM -- Segment Everything Everywhere All At Once
# Copyright (c) 2022 Microsoft
# Licensed under The MIT License [see LICENSE for details]
# Written by Xueyan Zou (xueyan@cs.wisc.edu), Jianwei Yang (jianwyan@microsoft.com)
# --------------------------------------------------------

import os
import warnings
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Tuple

# import gradio as gr
import torch
import argparse
import whisper
import numpy as np

# from gradio import processing_utils
from xdecoder.BaseModel import BaseModel
from xdecoder import build_model
from utils.distributed import init_distributed
from utils.arguments import load_opt_from_config_files
from utils.constants import COCO_PANOPTIC_CLASSES
from utils.constants import COCO_SEMANTIC_CLASSES
from dataset.cocodataset import cocoDataset
from utils.util import count_params, init_log, AverageMeter
from torch.utils.data import DataLoader
from torch.optim import SGD
from torch.utils.tensorboard import SummaryWriter
from classes import CLASSES
from evaluate import evaluate
from torch import nn
from tasks import *
import yaml
import logging
import torch.nn.functional as F
import os
from dataset import  maskfromer_panoptic_dataset_mapper


parser = argparse.ArgumentParser('SEEM Demo', add_help=False)
parser.add_argument('--conf_files', default="configs/seem/seem_focall_lang.yaml", metavar="FILE", help='path to config file', )
parser.add_argument('--yaml_file', default="configs/coco.yaml")
parser.add_argument('--save_path', default="./save/")
args = parser.parse_args()


def train():
    #############  读取模型文件并配置  ######################
    opt = load_opt_from_config_files(args.conf_files)
    opt = init_distributed(opt)

    if 'focalt' in args.conf_files:
        pretrained_pth = os.path.join("seem_focalt_v2.pt")
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focalt_v2.pt"))
    elif 'focal' in args.conf_files:
        pretrained_pth = "/data1/seem_focall_v1.pt"
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focall_v1.pt"))


    # model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).eval().cuda()
    model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).cuda()
    model.model.sem_seg_head.predictor.lang_encoder.get_text_embeddings(["background"] + COCO_SEMANTIC_CLASSES,
                                                                            is_eval=False)


    # with torch.no_grad():
    #     # print(COCO_PANOPTIC_CLASSES)
    #     model.model.sem_seg_head.predictor.lang_encoder.get_text_embeddings(COCO_PANOPTIC_CLASSES + ["background"],
    #                                                                         is_eval=True)
    # model = nn.DataParallel(model)

    ##########  设置训练模式，通用分割任务  ############################################################
    # model.task_switch['visual'] = False
    model.model.task_switch['spatial'] = False
    model.model.task_switch['visual'] = False
    model.model.task_switch['grounding'] = False
    model.model.task_switch['audio'] = False

    #############  读取训练文件并配置  ####################
    logger = init_log('global', logging.INFO)
    logger.propagate = 0
    cfg = yaml.load(open(args.yaml_file, "r"), Loader=yaml.Loader)
    writer = SummaryWriter(args.save_path)

    optimizer = SGD([param for name, param in model.named_parameters()], cfg['lr'], momentum=0.9, weight_decay=1e-4)

    trainset = cocoDataset(cfg['dataset'], cfg['data_root'], 'train',
                             cfg['crop_size'])
    valset = cocoDataset(cfg['dataset'], cfg['data_root'], 'val')

    trainloader = DataLoader(trainset, batch_size=cfg['batch_size'],
                               num_workers=0, drop_last=True)
    valloader = DataLoader(valset, batch_size=1, num_workers=0,
                           drop_last=False)

    total_iters = len(trainloader) * cfg['epochs']
    previous_best = 0.0
    epoch = -1
    rank = 0
    criterion = nn.CrossEntropyLoss(**cfg['criterion']['kwargs']).cuda()

    if os.path.exists(os.path.join(args.save_path, 'latest.pth')):
        checkpoint = torch.load(os.path.join(args.save_path, 'latest.pth'))
        model.load_state_dict(checkpoint['model'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        epoch = checkpoint['epoch']
        previous_best = checkpoint['previous_best']

    for epoch in range(epoch + 1, cfg['epochs']):
        logger.info('===========> Epoch: {:}, LR: {:.5f}, Previous best: {:.2f}'.format(
                epoch, optimizer.param_groups[0]['lr'], previous_best))

        total_loss = AverageMeter()

        for i, data in enumerate(trainloader):
            model.train()

            pred = model.model(data)
            mask = data["mask"].cuda()
            pred = [x["sem_seg"] for x in pred]
            pred = torch.stack(pred, dim=0)
            pred = pred.softmax(dim=1)

            loss = criterion(pred, mask)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            iters = epoch * len(trainloader) + i
            lr = cfg['lr'] * (1 - iters / total_iters) ** 0.9

            optimizer.param_groups[0]["lr"] = lr
            # optimizer.param_groups[1]["lr"] = lr * cfg['lr_multi']

            total_loss.update(loss.item())

            writer.add_scalar('train/loss_all', loss.item(), iters)

            if (i % (len(trainloader) // 8) == 0):
                logger.info(
                    'Iters: {:}, Total loss: {:.3f}'.format(i, total_loss.avg))

    eval_mode = 'original'
    mIoU, iou_class = evaluate(model.model, valloader, eval_mode, cfg)

    for (cls_idx, iou) in enumerate(iou_class):
        logger.info('***** Evaluation ***** >>>> Class [{:} {:}] '
                    'IoU: {:.2f}'.format(cls_idx, CLASSES[cfg['dataset']][cls_idx], iou))
    logger.info('***** Evaluation {} ***** >>>> MeanIoU: {:.2f}\n'.format(eval_mode, mIoU))

    writer.add_scalar('eval/mIoU', mIoU, epoch)
    for i, iou in enumerate(iou_class):
        writer.add_scalar('eval/%s_IoU' % (CLASSES[cfg['dataset']][i]), iou, epoch)

    is_best = mIoU > previous_best
    previous_best = max(mIoU, previous_best)
    if rank == 0:
        checkpoint = {
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'epoch': epoch,
            'previous_best': previous_best,
        }
        torch.save(checkpoint, os.path.join(args.save_path, 'latest.pth'))
        if is_best:
            torch.save(checkpoint, os.path.join(args.save_path, 'best.pth'))


if __name__ == '__main__':
    train()