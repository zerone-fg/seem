script_path=/data1/paintercoco/
cd $script_path$
method=/data1/paintercoco/main_train
output_dir=./output_dir/
gpu_num=8
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 python -m torch.distributed.launch --nproc_per_node=8 --use_env $method.py --output_dir $output_dir
