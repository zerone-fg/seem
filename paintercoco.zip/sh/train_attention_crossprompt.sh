script_path=/data1/paintercoco/
cd $script_path$
method=/data1/paintercoco/main_train
output_dir=./output_dir_attention_crossprompt/
gpu_num=4
CUDA_VISIBLE_DEVICES=0,1,2,3 python -m torch.distributed.launch --nproc_per_node=4 --use_env $method.py --output_dir $output_dir