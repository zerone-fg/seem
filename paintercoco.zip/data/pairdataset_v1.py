# --------------------------------------------------------
# Images Speak in Images: A Generalist Painter for In-Context Visual Learning (https://arxiv.org/abs/2212.02499)
# Github source: https://github.com/baaivision/Painter
# Copyright (c) 2022 Beijing Academy of Artificial Intelligence (BAAI)
# Licensed under The MIT License [see LICENSE for details]
# By Xinlong Wang, Wen Wang
# Based on MAE, BEiT, detectron2, Mask2Former, bts, mmcv, mmdetetection, mmpose, MIRNet, MPRNet, and Uformer codebases
# --------------------------------------------------------'

import os.path
import json
from typing import Any, Callable, List, Optional, Tuple
import random

from PIL import Image
import numpy as np

import torch
from torchvision.datasets.vision import VisionDataset, StandardTransform
from data.trainsam_transform import *
import data.pair_transforms as pair_transforms
from torchvision import transforms
import cv2 as cv


class PairDataset(VisionDataset):
    """`MS Coco Detection <https://cocodataset.org/#detection-2016>`_ Dataset.

    It requires the `COCO API to be installed <https://github.com/pdollar/coco/tree/master/PythonAPI>`_.

    Args:
        root (string): Root directory where images are downloaded to.
        annFile (string): Path to json annotation file.
        transform (callable, optional): A function/transform that  takes in an PIL image
            and returns a transformed version. E.g, ``transforms.PILToTensor``
        target_transform (callable, optional): A function/transform that takes in the
            target and transforms it.
        transforms (callable, optional): A function/transform that takes input sample and its target as entry
            and returns a transformed version.
    """

    def __init__(
            self,
            root: str,
            json_path_list: list,
            transform: Optional[Callable] = None,
            transform2: Optional[Callable] = None,
            transform3: Optional[Callable] = None,
            transform_seccrop: Optional[Callable] = None,
            target_transform: Optional[Callable] = None,
            transforms: Optional[Callable] = None,
            masked_position_generator: Optional[Callable] = None,
            use_two_pairs: bool = True,
            half_mask_ratio: float = 0.,
            state='train'
    ) -> None:
        super().__init__(root, transforms, transform, target_transform)

        self.pairs = []
        self.weights = []
        self.state = state
        type_weight_list = [0.1, 0.2, 0.15, 0.25, 0.2, 0.15, 0.05, 0.05]
        for idx, json_path in enumerate(json_path_list):
            cur_pairs = json.load(open(json_path))
            self.pairs.extend(cur_pairs)
            cur_num = len(cur_pairs)
            self.weights.extend([type_weight_list[idx] * 1. / cur_num] * cur_num)
            print(json_path, type_weight_list[idx])
        self.use_two_pairs = use_two_pairs
        if self.use_two_pairs:
            self.pair_type_dict = {}
            for idx, pair in enumerate(self.pairs):
                if "type" in pair:
                    if pair["type"] not in self.pair_type_dict:
                        self.pair_type_dict[pair["type"]] = [idx]
                    else:
                        self.pair_type_dict[pair["type"]].append(idx)
            for t in self.pair_type_dict:
                print(t, len(self.pair_type_dict[t]))
        self.transforms = PairStandardTransform(transform, target_transform) if transform is not None else None
        self.transforms2 = PairStandardTransform(transform2, target_transform) if transform2 is not None else None
        self.transforms3 = PairStandardTransform(transform3, target_transform) if transform3 is not None else None
        self.transforms_seccrop = PairStandardTransform(transform_seccrop,
                                                        target_transform) if transform_seccrop is not None else None
        self.masked_position_generator = masked_position_generator
        self.half_mask_ratio = half_mask_ratio

        panoptic_coco_categories = '/data1/paintercoco/data/panoptic_coco_categories.json'
        with open(panoptic_coco_categories, 'r') as f:
            categories_list = json.load(f)
        categories = {category['id']: category for category in categories_list}

        # define colors (dict of cat_id to color mapper)
        num_colors = len(categories)
        from data.coco_semseg.gen_color_coco_panoptic_segm import define_colors_by_mean_sep
        PALETTE_DICT = define_colors_by_mean_sep(num_colors=num_colors)
        PALETTE = [v for k, v in PALETTE_DICT.items()]
        self.palette_dict = PALETTE_DICT

        self.color2id = {}
        for k, v in PALETTE_DICT.items():
            self.color2id[v] = k
        self.palette = torch.tensor(PALETTE, dtype=torch.float)

        jsonfile_f = open("/data1/paintercoco/data/coco_semseg/coco_panotic_seg_class_{}2017.json".format(state),
                          encoding="utf-8")
        class_id_dict = json.load(jsonfile_f)

        self.class_id_dict = class_id_dict

    def post_process_segm_output(self, segm):
        """
        Post-processing to turn output segm image to class index map

        Args:
            segm: (H, W, 3)

        Returns:
            class_map: (H, W)
        """
        segm = torch.from_numpy(segm).float()  # (h, w, 3)
        h, w, k = segm.shape[0], segm.shape[1], self.palette.shape[0]

        dist = torch.abs(segm.view(h, w, 1, 3) - self.palette.view(1, 1, k, 3))  # (h, w, k)

        dist = torch.sum(dist, dim=-1)
        pred = dist.argmin(dim=-1).cpu()  # (h, w)
        pred = np.array(pred, dtype=np.int)

        return pred

    def _load_image(self, path: str) -> Image.Image:
        while True:
            try:
                img = Image.open(os.path.join(self.root, path))
            except OSError as e:
                print(f"Catched exception: {str(e)}. Re-trying...")
                import time
                time.sleep(1)
            else:
                break
        # process for nyuv2 depth: scale to 0~255
        if "sync_depth" in path:
            # nyuv2's depth range is 0~10m
            img = np.array(img) / 10000.
            img = img * 255
            img = Image.fromarray(img)
        img = img.convert("RGB")
        return img

    def _combine_images(self, image, image2, interpolation='bicubic'):
        h, w = image.shape[1], image.shape[2]
        dst = torch.cat([image, image2], dim=1)
        return dst

    def __getitem__(self, index: int) -> Tuple[Any, Any]:
        pair = self.pairs[index]
        image = self._load_image(pair['image_path'])
        target = self._load_image(pair['target_path'])

        t1 = torch.tensor(np.array(target)).reshape(-1, 3)
        target1_id = torch.unique(t1, dim=0)  #### unique turples

        target1_id = target1_id.tolist()

        target_t = torch.tensor(np.array(target).astype(np.uint8))

        ref_tar_mask = np.zeros(target_t.shape[:-1], dtype=np.uint8)
        target_mask = np.zeros(target_t.shape[:-1], dtype=np.uint8)

        store_ids = random.sample(target1_id, int(0.7 * len(target1_id)))

        ####### 重新选择几个颜色进行上色############
        ####### 先把store_ids对应的几个类别id取出来，然后在剩下的类别id中随机选择几个，取对应的颜色对mask重新上色

        cls_ids = []
        for choi in store_ids:
            if choi != [0, 0, 0]:
                cls_id = self.color2id[tuple(choi)]
                cls_ids.append(cls_id)
            else:
                cls_ids.append(-1)

        remain_cls_ids = list(set(list(np.arange(0, 132))) - set(cls_ids))
        new_cls_color = random.sample(remain_cls_ids, len(store_ids))
        target2 = target_t.clone()

        for id, choi in enumerate(store_ids):
            if choi != [0, 0, 0]:
                choi = torch.tensor(choi)
                mask_1 = target_t[:, :, 0] == choi[0]
                mask_2 = target_t[:, :, 1] == choi[1]
                mask_3 = target_t[:, :, 2] == choi[2]
                final_mask = torch.logical_and(torch.logical_and(mask_1, mask_2), mask_3)

                target2[final_mask] = torch.tensor(np.array(self.palette_dict[new_cls_color[id]]).astype(np.uint8))  ###### ref图像更改颜色
                target_t[final_mask] = torch.tensor(np.array(self.palette_dict[new_cls_color[id]]).astype(np.uint8)) ###### target图像更改颜色

                final_mask = final_mask.cpu().numpy().astype(np.uint8)
                num_labels, labels, stats, centroids = cv.connectedComponentsWithStats(final_mask, connectivity=8)

                choi_id = random.randint(1, num_labels-1)
                mask = labels == choi_id
                ref_tar_mask = np.logical_or(mask, ref_tar_mask)
                target_mask = np.logical_or(target_mask, final_mask)

        target_t[~torch.tensor(target_mask)] = torch.tensor(np.array([0, 0, 0]).astype(np.uint8))
        target2[~torch.tensor(ref_tar_mask)] = torch.tensor(np.array([0, 0, 0]).astype(np.uint8))

        pair_type = pair['type']
        if "depth" in pair_type or "pose" in pair_type:
            interpolation1 = 'bicubic'
            interpolation2 = 'bicubic'
        elif "image2" in pair_type:
            interpolation1 = 'bicubic'
            interpolation2 = 'nearest'
        elif "2image" in pair_type:
            interpolation1 = 'nearest'
            interpolation2 = 'bicubic'
        else:
            interpolation1 = 'bicubic'
            interpolation2 = 'bicubic'

        # no aug for instance segmentation
        if "inst" in pair['type'] and self.transforms2 is not None:
            cur_transforms = self.transforms2
        elif "pose" in pair['type'] and self.transforms3 is not None:
            cur_transforms = self.transforms3
        else:
            cur_transforms = self.transforms

        target = Image.fromarray(np.array(target_t).astype(np.uint8))
        target2 = Image.fromarray(np.array(target2).astype(np.uint8))

        # target.save("./target3.jpg")
        # target2.save("./target4.jpg")

        if self.use_two_pairs:
            image2 = self._load_image(pair['image_path'])
            image2, target2 = cur_transforms(image2, target2, interpolation1, interpolation2)

        if self.state == 'train':
            train_transform = pair_transforms.Compose([
                pair_transforms.RandomResizedCrop(448, scale=(0.3, 1.0), interpolation=3),
                pair_transforms.RandomHorizontalFlip()])
            image, target = train_transform(image, target, interpolation1, interpolation2)
            image = transforms.RandomApply([transforms.ColorJitter(0.4, 0.4, 0.2, 0.1)], p=0.8)(image)

        else:
            train_transform = pair_transforms.Compose([
                pair_transforms.RandomResizedCrop(448, scale=(0.9999, 1.0), interpolation=3)])
            image, target = train_transform(image, target, interpolation1, interpolation2)

        image = normalize(image)
        target = np.array(target).astype(np.uint8)
        ignore_mask = torch.tensor(target).sum(dim=-1) == 0
        target = self.post_process_segm_output(target)

        target[ignore_mask] = 133
        return image, torch.tensor(target), image2, target2

    def __len__(self) -> int:
        return len(self.pairs)


class PairStandardTransform(StandardTransform):
    def __init__(self, transform: Optional[Callable] = None, target_transform: Optional[Callable] = None) -> None:
        super().__init__(transform=transform, target_transform=target_transform)

    def __call__(self, input: Any, target: Any, interpolation1: Any, interpolation2: Any) -> Tuple[Any, Any]:
        if self.transform is not None:
            input, target = self.transform(input, target, interpolation1, interpolation2)
        return input, target
