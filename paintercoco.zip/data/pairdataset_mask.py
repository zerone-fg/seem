import os.path
import json
from typing import Any, Callable, List, Optional, Tuple
import random

from PIL import Image
import numpy as np

import torch
from torchvision.datasets.vision import VisionDataset, StandardTransform
from data.trainsam_transform import *
import data.pair_transforms as pair_transforms
from torchvision import transforms
import cv2 as cv


class PairDataset(VisionDataset):
    """`MS Coco Detection <https://cocodataset.org/#detection-2016>`_ Dataset.

    It requires the `COCO API to be installed <https://github.com/pdollar/coco/tree/master/PythonAPI>`_.

    Args:
        root (string): Root directory where images are downloaded to.
        annFile (string): Path to json annotation file.
        transform (callable, optional): A function/transform that  takes in an PIL image
            and returns a transformed version. E.g, ``transforms.PILToTensor``
        target_transform (callable, optional): A function/transform that takes in the
            target and transforms it.
        transforms (callable, optional): A function/transform that takes input sample and its target as entry
            and returns a transformed version.
    """

    def __init__(
            self,
            root: str,
            json_path_list: list,
            transform: Optional[Callable] = None,
            transform2: Optional[Callable] = None,
            transform3: Optional[Callable] = None,
            transform_seccrop: Optional[Callable] = None,
            target_transform: Optional[Callable] = None,
            transforms: Optional[Callable] = None,
            masked_position_generator: Optional[Callable] = None,
            use_two_pairs: bool = True,
            half_mask_ratio: float = 0.,
            state='train'
    ) -> None:
        super().__init__(root, transforms, transform, target_transform)

        self.pairs = []
        self.weights = []
        self.state = state
        type_weight_list = [0.1, 0.2, 0.15, 0.25, 0.2, 0.15, 0.05, 0.05]
        for idx, json_path in enumerate(json_path_list):
            cur_pairs = json.load(open(json_path))
            self.pairs.extend(cur_pairs)
            cur_num = len(cur_pairs)
            self.weights.extend([type_weight_list[idx] * 1. / cur_num] * cur_num)
            print(json_path, type_weight_list[idx])
        self.use_two_pairs = use_two_pairs
        if self.use_two_pairs:
            self.pair_type_dict = {}
            for idx, pair in enumerate(self.pairs):
                if "type" in pair:
                    if pair["type"] not in self.pair_type_dict:
                        self.pair_type_dict[pair["type"]] = [idx]
                    else:
                        self.pair_type_dict[pair["type"]].append(idx)
            for t in self.pair_type_dict:
                print(t, len(self.pair_type_dict[t]))
        self.transforms = PairStandardTransform(transform, target_transform) if transform is not None else None
        self.transforms2 = PairStandardTransform(transform2, target_transform) if transform2 is not None else None
        self.transforms3 = PairStandardTransform(transform3, target_transform) if transform3 is not None else None
        self.transforms_seccrop = PairStandardTransform(transform_seccrop,
                                                        target_transform) if transform_seccrop is not None else None
        self.masked_position_generator = masked_position_generator
        self.half_mask_ratio = half_mask_ratio

        panoptic_coco_categories = '/data1/paintercoco/data/panoptic_coco_categories.json'
        with open(panoptic_coco_categories, 'r') as f:
            categories_list = json.load(f)
        categories = {category['id']: category for category in categories_list}

        # define colors (dict of cat_id to color mapper)
        num_colors = len(categories)
        from data.coco_semseg.gen_color_coco_panoptic_segm import define_colors_by_mean_sep
        PALETTE_DICT = define_colors_by_mean_sep(num_colors=num_colors)
        PALETTE = [v for k, v in PALETTE_DICT.items()]
        self.palette_dict = PALETTE_DICT

        self.color2id = {}
        for k, v in PALETTE_DICT.items():
            self.color2id[v] = k
        self.palette = torch.tensor(PALETTE, dtype=torch.float)

        jsonfile_f = open("/data1/paintercoco/data/coco_semseg/coco_panotic_seg_class_{}2017.json".format(state),
                          encoding="utf-8")
        class_id_dict = json.load(jsonfile_f)

        self.class_id_dict = class_id_dict

    def post_process_segm_output(self, segm):
        """
        Post-processing to turn output segm image to class index map

        Args:
            segm: (H, W, 3)

        Returns:
            class_map: (H, W)
        """
        segm = torch.from_numpy(segm).float()  # (h, w, 3)
        h, w, k = segm.shape[0], segm.shape[1], self.palette.shape[0]

        dist = torch.abs(segm.view(h, w, 1, 3) - self.palette.view(1, 1, k, 3))  # (h, w, k)

        dist = torch.sum(dist, dim=-1)
        pred = dist.argmin(dim=-1).cpu()  # (h, w)
        pred = np.array(pred, dtype=np.int)

        return pred

    def _load_image(self, path: str) -> Image.Image:
        while True:
            try:
                img = Image.open(os.path.join(self.root, path))
            except OSError as e:
                print(f"Catched exception: {str(e)}. Re-trying...")
                import time
                time.sleep(1)
            else:
                break
        # process for nyuv2 depth: scale to 0~255
        if "sync_depth" in path:
            # nyuv2's depth range is 0~10m
            img = np.array(img) / 10000.
            img = img * 255
            img = Image.fromarray(img)
        img = img.convert("RGB")
        return img

    def _combine_images(self, image, image2, interpolation='bicubic'):
        # image under image2
        h, w = image.shape[1], image.shape[2]
        dst = torch.cat([image, image2], dim=1)
        return dst

    def __getitem__(self, index: int) -> Tuple[Any, Any]:
        pair = self.pairs[index]
        image = self._load_image(pair['image_path'])
        target = self._load_image(pair['target_path'])

        t1 = torch.tensor(np.array(target)).reshape(-1, 3)
        target1_id = torch.unique(t1, dim=0)  #### unique turples
        target1_id = target1_id.tolist()

        target_t = torch.tensor(np.array(target).astype(np.uint8))
        h, w, _ = target_t.shape

        pos_target = torch.zeros((10, h, w), dtype=torch.uint8)
        ref_in = torch.zeros((10, h, w), dtype=torch.uint8)

        ref_tar_mask = np.zeros(target_t.shape[:-1], dtype=np.uint8)
        target_mask = np.zeros(target_t.shape[:-1], dtype=np.uint8)

        if len(target1_id) > 10:
            pos_ids = random.sample(target1_id, len(target1_id))[:10]
        else:
            pos_ids = random.sample(target1_id, len(target1_id))

        for id, choi in enumerate(pos_ids):
            if choi != [0, 0, 0]:
                choi = torch.tensor(choi)
                mask_1 = target_t[:, :, 0] == choi[0]
                mask_2 = target_t[:, :, 1] == choi[1]
                mask_3 = target_t[:, :, 2] == choi[2]
                final_mask = torch.logical_and(torch.logical_and(mask_1, mask_2), mask_3)

                final_mask = final_mask.cpu().numpy().astype(np.uint8)
                num_labels, labels, stats, centroids = cv.connectedComponentsWithStats(final_mask, connectivity=8)

                choi_id = random.randint(1, num_labels-1)
                mask = labels == choi_id

                ref_in[id, mask] = 1
                pos_target[id, final_mask] = 1

        pair_type = pair['type']
        if "depth" in pair_type or "pose" in pair_type:
            interpolation1 = 'bicubic'
            interpolation2 = 'bicubic'
        elif "image2" in pair_type:
            interpolation1 = 'bicubic'
            interpolation2 = 'nearest'
        elif "2image" in pair_type:
            interpolation1 = 'nearest'
            interpolation2 = 'bicubic'
        else:
            interpolation1 = 'bicubic'
            interpolation2 = 'bicubic'

        # no aug for instance segmentation
        if "inst" in pair['type'] and self.transforms2 is not None:
            cur_transforms = self.transforms2
        elif "pose" in pair['type'] and self.transforms3 is not None:
            cur_transforms = self.transforms3
        else:
            cur_transforms = self.transforms

        target = pos_target
        target2 = ref_in

        # #######  可视化一下ref和对应的target #########################
        # for i in range(ref_in.shape[0]):
        #     img = Image.fromarray(np.array(ref_in[i]) * 255)
        #     img.save("ref{}.jpg".format(i))
        #     img_t = Image.fromarray(np.array(target[i] * 255))
        #     img_t.save("tar{}.jpg".format(i))

        if self.state == 'train':
            train_transform = pair_transforms.Compose([
                pair_transforms.RandomResizedCrop(448, scale=(0.3, 1.0), interpolation=3)])
            image, target = train_transform(image, target, interpolation1, interpolation2)

        else:
            train_transform = pair_transforms.Compose([
                pair_transforms.RandomResizedCrop(448, scale=(0.9999, 1.0), interpolation=3)])
            image, target = train_transform(image, target, interpolation1, interpolation2)

        if self.use_two_pairs:
            image2 = self._load_image(pair['image_path'])
            image2, target2 = cur_transforms(image2, target2, interpolation1, interpolation2)

        image = normalize(image)
        image2 = normalize(image2)

        target = np.array(target).astype(np.uint8)
        return image, torch.tensor(target), image2, target2.to(torch.float32)


    def __len__(self) -> int:
        return len(self.pairs)


class PairStandardTransform(StandardTransform):
    def __init__(self, transform: Optional[Callable] = None, target_transform: Optional[Callable] = None) -> None:
        super().__init__(transform=transform, target_transform=target_transform)

    def __call__(self, input: Any, target: Any, interpolation1: Any, interpolation2: Any) -> Tuple[Any, Any]:
        if self.transform is not None:
            input, target = self.transform(input, target, interpolation1, interpolation2)
        return input, target
