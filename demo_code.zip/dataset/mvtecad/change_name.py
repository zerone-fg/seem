##### 读取每个文件夹的图片转为相应的object_defect_lid的命名方式，分别存到train文件夹和annotations文件夹中
##### 处理完数据之后，改成coco的格式进行存储

import os
import shutil
import random

root_dir = "/data1/mvetad/"
new_root_dir = "/data1/mvetad_deal/"
train_list = []
val_list = []
anno_train = []
anno_val = []

if not os.path.exists(os.path.join(new_root_dir, "train")):
    os.makedirs(os.path.join(new_root_dir, "train"))
if not os.path.exists(os.path.join(new_root_dir, "train_anno")):
    os.makedirs(os.path.join(new_root_dir, "train_anno"))
if not os.path.exists(os.path.join(new_root_dir, "val")):
    os.makedirs(os.path.join(new_root_dir, "val"))
if not os.path.exists(os.path.join(new_root_dir, "val_anno")):
    os.makedirs(os.path.join(new_root_dir, "val_anno"))

for object in os.listdir(root_dir):  ### object level
    if object == 'license.txt':
        continue
    if object == 'readme.txt':
        continue
    object_name = object
    file_path_1 = os.path.join(root_dir, object_name)
    for attr in os.listdir(file_path_1):  #### 几个固定类别
        #### 对于训练文件夹来说，里面的数据都是训练集，加入到训练的list
        #### 对于test文件夹来说，每个state取出10%添加到train中，剩下的放到val中
        #### 对于groundtruth来说，添加到对应的anno中
        if attr == 'license.txt':
            continue
        if attr == 'readme.txt':
            continue
        if attr == 'ground_truth':
            continue
        file_path_2 = os.path.join(file_path_1, attr)
        for state in os.listdir(file_path_2): ### state-level
            file_path_3 = os.path.join(file_path_2, state)
            file_list = os.listdir(file_path_3)
            file_list = set(file_list)
            if 'Thumbs.db' in file_list:
                file_list.remove('Thumbs.db')
            file_list = list(file_list)

            if attr == 'train':
                ns= len(file_list)
                training_samples = random.sample(file_list, ns)
                for file in training_samples:
                    ori_name = os.path.join(file_path_3, file)
                    img_name = "{}_{}_{}".format(object, state, file)
                    shutil.move(ori_name, os.path.join(new_root_dir, "train", img_name))
                    # shutil.copy(ori_name, "1.png")
            else:
                ns = int(0.8 * len(file_list))
                training_samples = random.sample(file_list, ns)
                val_samples = list(set(file_list)-set(training_samples))
                for file in training_samples:
                    ori_name = os.path.join(file_path_3, file)
                    img_name = "{}_{}_{}".format(object, state, file)
                    if state != 'good':
                        ori_anno_name = ori_name.replace(attr, 'ground_truth').split('.')[0] + '_mask.png'
                        anno_name = "{}_{}_{}".format(object, state, file)
                        shutil.move(ori_anno_name, os.path.join(new_root_dir, "train_anno", anno_name))
                    shutil.move(ori_name, os.path.join(new_root_dir, "train", img_name))

                for file in val_samples:
                    ori_name = os.path.join(file_path_3, file)
                    img_name = "{}_{}_{}".format(object, state, file)
                    if state != 'good':
                        ori_anno_name = ori_name.replace(attr, 'ground_truth').split('.')[0] + '_mask.png'
                        anno_name = "{}_{}_{}".format(object, state, file)
                        shutil.move(ori_anno_name, os.path.join(new_root_dir, "val_anno", anno_name))

                    shutil.move(ori_name, os.path.join(new_root_dir, "val", img_name))

    print(object)











