try:
    # ignore ShapelyDeprecationWarning from fvcore
    from shapely.errors import ShapelyDeprecationWarning
    import warnings
    warnings.filterwarnings('ignore', category=ShapelyDeprecationWarning)
except:
    pass

import copy
import itertools
import logging
import os

from collections import OrderedDict
from typing import Any, Dict, List, Set

import torch
from torch.utils.tensorboard import SummaryWriter
import detectron2.utils.comm as comm
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.config import get_cfg
from detectron2.data import MetadataCatalog, build_detection_train_loader, build_detection_test_loader
from detectron2.engine import (
    DefaultTrainer,
    default_argument_parser,
    default_setup,
    launch,
)
from detectron2.evaluation import (
    COCOEvaluator,
    COCOPanopticEvaluator,
    DatasetEvaluators,
    SemSegEvaluator,
    verify_results,
)
from detectron2.projects.deeplab import add_deeplab_config, build_lr_scheduler
from detectron2.solver.build import maybe_add_gradient_clipping
from detectron2.utils.logger import setup_logger
import argparse
# MaskFormer
from dataset.maskfromer_panoptic_dataset_mapper import MaskFormerPanopticDatasetMapperTrain, MaskFormerPanopticDatasetMapperTest
from dataset.mask_former_semantic_dataset_mapper import MaskFormerSemanticDatasetMapper
from configs.config import add_maskformer2_config
from dataset.register_coco_panptic_anno import register_all_coco_panoptic_annos_sem_seg

from xdecoder.BaseModel import BaseModel
from xdecoder import build_model
from utils.distributed import init_distributed
from utils.arguments import load_opt_from_config_files
from torch.optim import SGD
from utils.constants import COCO_PANOPTIC_CLASSES
from utils.util import count_params, init_log, AverageMeter
import logging
import yaml
import numpy as np
from evaluate import evaluate
from classes import CLASSES
from detectron2.engine import DefaultTrainer
from torch.optim import AdamW
from utils.util import count_params, AverageMeter, intersectionAndUnion, init_log
from collections import defaultdict
from PIL import Image
import imgviz
import torch.distributed as dist
from detectron2.engine import (
    DefaultTrainer,
    default_argument_parser,
    default_setup,
    hooks,
    launch,
    create_ddp_model,
    AMPTrainer,
    SimpleTrainer
)

CUDA_VISIBLE_DEVICES=1

def save_colored_mask(mask, save_path):
    lbl_pil = Image.fromarray(mask.astype(np.uint8), mode="P")
    colormap = imgviz.label_colormap()
    lbl_pil.putpalette(colormap.flatten())
    lbl_pil.save(save_path)

#######  backbone and decoder using pretrained ckpt and both without freezing  #####
def setup(args):
    """
    Create configs and perform basic setups.
    """
    cfg = get_cfg()
    # for poly lr schedule
    add_deeplab_config(cfg)
    add_maskformer2_config(cfg)
    cfg.merge_from_file(
        "/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/configs/maskformer2_R50_bs16_50ep.yaml")
    # cfg.merge_from_list(args.opts)
    cfg.freeze()
    default_setup(cfg, args)
    # Setup logger for "mask_former" module
    setup_logger(output=cfg.OUTPUT_DIR, distributed_rank=comm.get_rank(), name="mask2former")
    return cfg

def main():
    parser = argparse.ArgumentParser('SEEM Demo', add_help=False)
    parser.add_argument('--conf_files', default="/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/configs/seem/seem_focall_lang.yaml", metavar="FILE",
                        help='path to config file', )
    parser.add_argument('--yaml_file', default="/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/configs/coco.yaml")
    parser.add_argument('--save_path', default="/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/save_text/")
    parser.add_argument("--local_rank", default=os.getenv('LOCAL_RANK', -1), type=int)
    args = parser.parse_args()


    #############  读取模型文件并配置  ######################
    opt = load_opt_from_config_files(args.conf_files)
    opt = init_distributed(opt)

    if args.local_rank != -1:
        torch.cuda.set_device(args.local_rank)
        device = torch.device("cuda", args.local_rank)
        torch.distributed.init_process_group(backend="nccl", init_method='env://')

    if 'focalt' in args.conf_files:
        pretrained_pth = os.path.join("seem_focalt_v2.pt")
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focalt_v2.pt"))
    elif 'focal' in args.conf_files:
        pretrained_pth = "/data1/seem_focall_v1.pt"
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focall_v1.pt"))

    model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).cuda()
    model.model.sem_seg_head.predictor.lang_encoder.get_text_embeddings(COCO_PANOPTIC_CLASSES + ["background"],
                                                                        is_eval=True)


    # model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).eval().cuda()
    # with torch.no_grad():
    #     model.model.sem_seg_head.predictor.lang_encoder.get_text_embeddings(COCO_PANOPTIC_CLASSES + ["background"],
    #                                                                         is_eval=True)
    ##########  设置训练模式，通用分割任务  ############################################################
    # model.task_switch['visual'] = False
    model.model.task_switch['spatial'] = False
    model.model.task_switch['visual'] = False
    model.model.task_switch['grounding'] = True
    model.model.task_switch['audio'] = False

    #############  读取训练文件并配置  ####################
    cfg_yaml = yaml.load(open(args.yaml_file, "r"), Loader=yaml.Loader)
    optimizer = AdamW([param for name, param in model.named_parameters()], 2e-5, weight_decay=1e-4)

    logger = init_log('global', logging.INFO)
    writer = SummaryWriter(args.save_path)
    logger.propagate = 0

    previous_best = 0.0
    epoch = -1
    rank = 0

    cfg = setup(args)

    register_all_coco_panoptic_annos_sem_seg()

    previous_best = 0.0
    # if os.path.exists(os.path.join(args.save_path, 'latest.pth')):
    #     checkpoint = torch.load(os.path.join(args.save_path, 'latest.pth'))
    #     model.load_state_dict(checkpoint['model'])
    #     optimizer.load_state_dict(checkpoint['optimizer'])
    #     epoch = checkpoint['epoch']
    #     previous_best = checkpoint['previous_best']

    ##########  分布式训练  #######################################################################
    # model.to(device)
    # num_gpus = torch.cuda.device_count()
    #
    # if num_gpus > 1:
    #     print('use {} gpus!'.format(num_gpus))
    #     model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank],
    #                                                       output_device=args.local_rank)

    ####################  加载相应的数据集  #######################################################

    mapper_train = MaskFormerPanopticDatasetMapperTrain(cfg, True)
    mapper_test = MaskFormerPanopticDatasetMapperTest(cfg, False)

    train_loader = build_detection_train_loader(cfg, mapper=mapper_train)

    val_dataset_name = "coco_2017_val_panoptic_with_sem_seg"
    val_loader = build_detection_test_loader(cfg, mapper=mapper_test, dataset_name=val_dataset_name)

    evaluator_list = []
    evaluator_type = MetadataCatalog.get(val_dataset_name).evaluator_type
    output_folder = os.path.join(cfg.OUTPUT_DIR, "inference")

    if evaluator_type == "coco_panoptic_seg" and cfg.MODEL.MASK_FORMER.TEST.SEMANTIC_ON:
        evaluator_list.append(SemSegEvaluator(val_dataset_name, distributed=True, output_dir=output_folder))
    evaluator = evaluator_list[0]

    total_iters = len(train_loader) * 30

    for epoch in range(epoch + 1, cfg_yaml['epochs']):
        logger.info('===========> Epoch: {:}, LR: {:.5f}, Previous best: {:.2f}'.format(
                epoch, optimizer.param_groups[0]['lr'], previous_best))

        total_loss = AverageMeter()

        for i, data in enumerate(train_loader):
            model.train()

            # print(len(data))
            # loss = model.model(data)
            # losses = sum(loss.values())
            #
            # torch.distributed.barrier()
            #
            # optimizer.zero_grad()
            # losses.backward()
            # optimizer.step()
            # iters = epoch * len(train_loader) + i
            #
            # total_loss.update(losses.item())
            #
            # writer.add_scalar('train/loss_all', losses.item(), iters)
            #
            # if (i % (len(train_loader) // 8) == 0):
            #     logger.info(
            #         'Iters: {:}, Total loss: {:.3f}'.format(i, total_loss.avg))
            #
            if ((i) % 3000) == 0:
                model.eval()
                intersect = torch.zeros((133)).cuda()
                union = torch.zeros((133)).cuda()

                with torch.no_grad():
                    for idx, input in enumerate(val_loader):
                        pred = model(input, 'grounding_refcoco')

                        pred = pred[-1]['grounding_mask'] > 0.0
                        mask = input[0]["groundings"]["masks"]

                        pred = pred.view(-1, mask.shape[0], pred.shape[-2], pred.shape[-1]).transpose(0, 1)  ### (30, 5)


                        tar_class = input[0]["groundings"]["hash"]

                        pred = pred.long().cuda()
                        mask = mask.long().cuda()


                        tar_class_dict = defaultdict(list)
                        for i in range(len(tar_class)):
                            tar_class_dict[tar_class[i]].append(i)

                        for key, l in tar_class_dict.items():
                            tar_union = np.zeros((mask.shape[-2:]))
                            for ite in l:
                                tar_union = np.logical_or(tar_union, mask[ite].cpu().numpy())

                            index = l[0]
                            pred_1 = pred[index].cpu().numpy()

                            for i in range(pred_1.shape[0]):
                                pred_1_1 = pred_1[i]
                                save_colored_mask(pred_1_1,
                                                  "/data1/Segment-Everything-Everywhere-All-At-Once-main_v3/demo_code/{}.png".format(
                                                      i))

                            inter_per_instan = \
                                   np.where(np.logical_and(pred_1 == tar_union, pred_1 == 1))[0].shape[0]
                            union_per_instan = pred_1.sum() + tar_union.sum() - inter_per_instan

                            intersect[key] += inter_per_instan
                            union[key] += union_per_instan

                    iou_class = intersect / union
                    mIOU = np.mean(iou_class * 100)
                    print("segment IOU is {}".format(mIOU))


































                    # #     之前的设计，只考虑相似度最高的进行计算  ##############################################
                    # #     tar_class_dict = defaultdict(list)
                    # #     for i in range(len(tar_class)):
                    # #         tar_class_dict[tar_class[i]].append(i)
                    # #
                    # #     for key, l in tar_class_dict.items():
                    # #         pred_union = np.zeros((pred.shape[-2:]))
                    # #         tar_union = np.zeros((mask.shape[-2:]))
                    # #         for ite in l:
                    # #             pred_union = np.logical_or(pred_union, pred[ite])
                    # #             tar_union = np.logical_or(tar_union, mask[ite])
                    # #
                    # #         save_colored_mask(pred_union,
                    # #                           "/data1/Segment-Everything-Everywhere-All-At-Once-main/pred_{}.png".format(
                    # #                               ite + 50))
                    # #
                    # #         inter_per_instan = \
                    # #         np.where(np.logical_and(pred_union == tar_union, pred_union == 1))[0].shape[0]
                    # #         union_per_instan = pred_union.sum() + tar_union.sum() - inter_per_instan
                    # #
                    # #         intersect[key] += inter_per_instan
                    # #         union[key] += union_per_instan
                    # #
                    # # iou_class = intersect / union
                    # # mIOU = np.mean(iou_class * 100)
                    # # print("segment IOU is {}".format(mIOU))
                    #
                    #
                    # ################ 考虑topk个进行计算  ###################################################
                    #     tar_class_dict = defaultdict(list)
                    #
                    #     for i in range(len(tar_class)):
                    #         tar_class_dict[tar_class[i]].append(i)
                    #
                    #
                    #     for key, l in tar_class_dict.items():  ### 每个类别以及相应的位置
                    #         tar_union = torch.zeros((mask.shape[-2:])).cuda()
                    #         pred_union = torch.zeros((pred.shape[-2:])).cuda()
                    #
                    #         for ite in l:
                    #             tar_union = torch.logical_or(tar_union, mask[ite])
                    #             # if len(l) <=5:
                    #             #     for i in range(len(l)):
                    #             #         pred_union = torch.logical_or(pred_union, pred[ite][i])
                    #             # else:
                    #             #     for i in range(5):
                    #             #         pred_union = torch.logical_or(pred_union, pred[ite][i])
                    #
                    #             # pred_union = pred_union.astype(np.int)
                    #             # save_colored_mask(pred_union, "/data1/Segment-Everything-Everywhere-All-At-Once-main/pred_{}.png".format(ite + 30))
                    #             # save_colored_mask(tar_union,
                    #             #                   "/data1/Segment-Everything-Everywhere-All-At-Once-main/tar_{}.png".format(
                    #             #                       ite + 30))
                    #             for i in range(101):
                    #                 pred_1 = pred[ite][i].cpu().numpy().astype(np.int)
                    #                 save_colored_mask(pred_1,
                    #                                   "/data1/Segment-Everything-Everywhere-All-At-Once-main/pred_{}.png".format(
                    #                                       ite + i))
                    #             break
                    #
                    #         inter_per_instan = \
                    #             torch.where(torch.logical_and(pred_union == tar_union, pred_union == True))[0].shape[0]
                    #         union_per_instan = pred_union.sum() + tar_union.sum() - inter_per_instan
                    #
                    #         # dist.all_reduce(torch.tensor(inter_per_instan).cuda())
                    #         # dist.all_reduce(torch.tensor(union_per_instan).cuda())
                    #
                    #         intersect[key] += inter_per_instan
                    #         union[key] += union_per_instan
                    #
                    #     print(idx)
                    #
                    # iou_class = intersect / union
                    # mIOU = torch.mean(iou_class * 100)

                    if rank == 0:
                        print("segment IOU is {}".format(mIOU))

                        is_best = mIOU > previous_best
                        previous_best = max(mIOU, previous_best)
                        if rank == 0:
                            checkpoint = {
                                'model': model.state_dict(),
                                'optimizer': optimizer.state_dict(),
                                'epoch': epoch,
                                'previous_best': previous_best,
                            }
                            torch.save(checkpoint, os.path.join(args.save_path, 'latest.pth'))
                            if is_best:
                                torch.save(checkpoint, os.path.join(args.save_path, 'best.pth'))

if __name__ == "__main__":
    main()



