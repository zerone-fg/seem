import logging
import math
from typing import Optional

import numpy
import torch
from torch import nn, Tensor
from torch.nn import functional as F

from timm.models.layers import trunc_normal_
from detectron2.layers import Conv2d
import fvcore.nn.weight_init as weight_init

from .utils.utils import rand_sample, prepare_features
from .utils.attn import MultiheadAttention
from .utils.attention_data_struct import AttentionDataStruct
from .registry import register_decoder
from ...utils import configurable
from ...modules import PositionEmbeddingSine
from ...modules.point_features import point_sample


class MLP_1(nn.Module):

    def __init__(self, dim):
        super(MLP_1, self).__init__()
        self.fc1 = nn.Linear(dim, dim * 4)
        self.fc2 = nn.Linear(dim * 4, dim)
        self.act = nn.functional.gelu
        self.dropout = nn.Dropout(0.1)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.fc2(x)
        x = self.dropout(x)
        return x

class SelfAttentionLayer(nn.Module):

    def __init__(self, d_model, nhead, dropout=0.0,
                 activation="relu", normalize_before=False):
        super().__init__()
        self.self_attn = MultiheadAttention(d_model, nhead, dropout=dropout)

        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        self.activation = _get_activation_fn(activation)
        self.normalize_before = normalize_before

        self._reset_parameters()

    def _reset_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def with_pos_embed(self, tensor, pos: Optional[Tensor]):
        return tensor if pos is None else tensor + pos

    def forward_post(self, tgt,
                     tgt_mask: Optional[Tensor] = None,
                     tgt_key_padding_mask: Optional[Tensor] = None,
                     query_pos: Optional[Tensor] = None):
        q = k = self.with_pos_embed(tgt, query_pos)
        tgt2 = self.self_attn(q, k, value=tgt, attn_mask=tgt_mask,
                              key_padding_mask=tgt_key_padding_mask)[0]
        tgt = tgt + self.dropout(tgt2)
        tgt = self.norm(tgt)

        return tgt

    def forward_pre(self, tgt,
                    tgt_mask: Optional[Tensor] = None,
                    tgt_key_padding_mask: Optional[Tensor] = None,
                    query_pos: Optional[Tensor] = None):
        tgt2 = self.norm(tgt)
        q = k = self.with_pos_embed(tgt2, query_pos)
        tgt2 = self.self_attn(q, k, value=tgt2, attn_mask=tgt_mask,
                              key_padding_mask=tgt_key_padding_mask)[0]
        tgt = tgt + self.dropout(tgt2)

        return tgt

    def forward(self, tgt,
                tgt_mask: Optional[Tensor] = None,
                tgt_key_padding_mask: Optional[Tensor] = None,
                query_pos: Optional[Tensor] = None):
        if self.normalize_before:
            return self.forward_pre(tgt, tgt_mask,
                                    tgt_key_padding_mask, query_pos)
        return self.forward_post(tgt, tgt_mask,
                                 tgt_key_padding_mask, query_pos)


class CrossAttentionLayer(nn.Module):

    def __init__(self, d_model, nhead, dropout=0.0,
                 activation="relu", normalize_before=False):
        super().__init__()
        self.multihead_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)

        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        self.activation = _get_activation_fn(activation)
        self.normalize_before = normalize_before

        self._reset_parameters()

    def _reset_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def with_pos_embed(self, tensor, pos: Optional[Tensor]):
        return tensor if pos is None else tensor + pos

    def forward_post(self, tgt, memory,
                     memory_mask: Optional[Tensor] = None,
                     memory_key_padding_mask: Optional[Tensor] = None,
                     pos: Optional[Tensor] = None,
                     query_pos: Optional[Tensor] = None):
        tgt2, avg_attn = self.multihead_attn(query=self.with_pos_embed(tgt, query_pos),
                                             key=self.with_pos_embed(memory, pos),
                                             value=memory, attn_mask=memory_mask,
                                             key_padding_mask=memory_key_padding_mask)
        tgt = tgt + self.dropout(tgt2)
        tgt = self.norm(tgt)
        return tgt, avg_attn

    def forward_pre(self, tgt, memory,
                    memory_mask: Optional[Tensor] = None,
                    memory_key_padding_mask: Optional[Tensor] = None,
                    pos: Optional[Tensor] = None,
                    query_pos: Optional[Tensor] = None):
        tgt2 = self.norm(tgt)
        tgt2, avg_attn = self.multihead_attn(query=self.with_pos_embed(tgt2, query_pos),
                                             key=self.with_pos_embed(memory, pos),
                                             value=memory, attn_mask=memory_mask,
                                             key_padding_mask=memory_key_padding_mask)
        tgt = tgt + self.dropout(tgt2)

        return tgt, avg_attn

    def forward(self, tgt, memory,
                memory_mask: Optional[Tensor] = None,
                memory_key_padding_mask: Optional[Tensor] = None,
                pos: Optional[Tensor] = None,
                query_pos: Optional[Tensor] = None):
        if self.normalize_before:
            return self.forward_pre(tgt, memory, memory_mask,
                                    memory_key_padding_mask, pos, query_pos)
        return self.forward_post(tgt, memory, memory_mask,
                                 memory_key_padding_mask, pos, query_pos)


class FFNLayer(nn.Module):

    def __init__(self, d_model, dim_feedforward=2048, dropout=0.0,
                 activation="relu", normalize_before=False):
        super().__init__()
        # Implementation of Feedforward model
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.norm = nn.LayerNorm(d_model)

        self.activation = _get_activation_fn(activation)
        self.normalize_before = normalize_before

        self._reset_parameters()

    def _reset_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def with_pos_embed(self, tensor, pos: Optional[Tensor]):
        return tensor if pos is None else tensor + pos

    def forward_post(self, tgt):
        tgt2 = self.linear2(self.dropout(self.activation(self.linear1(tgt))))
        tgt = tgt + self.dropout(tgt2)
        tgt = self.norm(tgt)
        return tgt

    def forward_pre(self, tgt):
        tgt2 = self.norm(tgt)
        tgt2 = self.linear2(self.dropout(self.activation(self.linear1(tgt2))))
        tgt = tgt + self.dropout(tgt2)
        return tgt

    def forward(self, tgt):
        if self.normalize_before:
            return self.forward_pre(tgt)
        return self.forward_post(tgt)


def _get_activation_fn(activation):
    """Return an activation function given a string"""
    if activation == "relu":
        return F.relu
    if activation == "gelu":
        return F.gelu
    if activation == "glu":
        return F.glu
    raise RuntimeError(F"activation should be relu/gelu, not {activation}.")


class MLP(nn.Module):
    """ Very simple multi-layer perceptron (also called FFN)"""

    def __init__(self, input_dim, hidden_dim, output_dim, num_layers):
        super().__init__()
        self.num_layers = num_layers
        h = [hidden_dim] * (num_layers - 1)
        self.layers = nn.ModuleList(nn.Linear(n, k) for n, k in zip([input_dim] + h, h + [output_dim]))

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < self.num_layers - 1 else layer(x)
        return x


class MultiScaleMaskedTransformerDecoder(nn.Module):
    _version = 2

    @configurable
    def __init__(
            self,
            lang_encoder: nn.Module,
            in_channels,
            mask_classification=True,
            *,
            hidden_dim: int,
            dim_proj: int,
            num_queries: int,
            contxt_len: int,
            nheads: int,
            dim_feedforward: int,
            dec_layers: int,
            pre_norm: bool,
            mask_dim: int,
            task_switch: dict,
            enforce_input_project: bool,
            max_spatial_len: int,
            attn_arch: dict,
    ):

        super().__init__()
        assert mask_classification, "Only support mask classification model"
        self.mask_classification = mask_classification

        # positional encoding
        N_steps = hidden_dim // 2
        self.pe_layer = PositionEmbeddingSine(N_steps, normalize=True)

        # define Transformer decoder here
        self.num_heads = nheads
        self.num_layers = dec_layers
        self.contxt_len = contxt_len
        self.transformer_self_attention_layers = nn.ModuleList()
        self.transformer_cross_attention_layers = nn.ModuleList()
        self.transformer_ffn_layers = nn.ModuleList()

        for _ in range(self.num_layers):
            self.transformer_self_attention_layers.append(
                SelfAttentionLayer(
                    d_model=hidden_dim,
                    nhead=nheads,
                    dropout=0.0,
                    normalize_before=pre_norm,
                )
            )

            self.transformer_cross_attention_layers.append(
                CrossAttentionLayer(
                    d_model=hidden_dim,
                    nhead=nheads,
                    dropout=0.0,
                    normalize_before=pre_norm,
                )
            )

            self.transformer_ffn_layers.append(
                FFNLayer(
                    d_model=hidden_dim,
                    dim_feedforward=dim_feedforward,
                    dropout=0.0,
                    normalize_before=pre_norm,
                )
            )

        self.decoder_norm = nn.LayerNorm(hidden_dim)

        self.num_queries = num_queries
        # learnable query features
        self.query_feat = nn.Embedding(num_queries, hidden_dim)
        # learnable query p.e.
        self.query_embed = nn.Embedding(num_queries, hidden_dim)
        # learnable positive negative indicator
        self.pn_indicator = nn.Embedding(2, hidden_dim)

        # level embedding (we always use 3 scales)
        self.num_feature_levels = 3
        self.level_embed = nn.Embedding(self.num_feature_levels, hidden_dim)
        self.input_proj = nn.ModuleList()

        for _ in range(self.num_feature_levels):
            if in_channels != hidden_dim or enforce_input_project:
                self.input_proj.append(Conv2d(in_channels, hidden_dim, kernel_size=1))
                weight_init.c2_xavier_fill(self.input_proj[-1])
            else:
                self.input_proj.append(nn.Sequential())

        self.task_switch = task_switch
        self.query_index = {}

        # output FFNs
        self.lang_encoder = lang_encoder
        if self.task_switch['mask']:
            self.mask_embed = MLP(hidden_dim, hidden_dim, mask_dim, 3)

        self.class_embed = nn.Parameter(torch.empty(hidden_dim, dim_proj))
        trunc_normal_(self.class_embed, std=.02)

        if task_switch['bbox']:
            self.bbox_embed = MLP(hidden_dim, hidden_dim, 4, 3)

        if task_switch['spatial']:
            # spatial query
            self.mask_sptial_embed = nn.ParameterList(
                [nn.Parameter(torch.empty(hidden_dim, hidden_dim)) for x in range(3)])
            trunc_normal_(self.mask_sptial_embed[0], std=.02)
            trunc_normal_(self.mask_sptial_embed[1], std=.02)
            trunc_normal_(self.mask_sptial_embed[2], std=.02)

            self.max_spatial_len = max_spatial_len
            # spatial memory
            num_spatial_memories = attn_arch['SPATIAL_MEMORIES']
            self.spatial_embed = nn.Embedding(num_spatial_memories, hidden_dim)
            self.spatial_featured = nn.Embedding(num_spatial_memories, hidden_dim)

        # build AttentionDataStruct
        attn_arch['NUM_LAYERS'] = self.num_layers
        self.attention_data = AttentionDataStruct(attn_arch, task_switch)


        self.norm1 = nn.LayerNorm(512)
        self.norm2 = nn.LayerNorm(512)
        self.win_size = 1
        self.m = nn.MaxPool2d(kernel_size=(self.win_size, self.win_size), stride=self.win_size, return_indices=True)
        self.pos_embedding = nn.Conv2d(512, 512, self.win_size, self.win_size)

        self.extra_cross_atten = nn.ModuleList()
        self.extra_ffn = nn.ModuleList()

        for j in range(3):
            self.extra_cross_atten.append(CrossAttentionLayer(d_model=hidden_dim,
                    nhead=nheads,
                    dropout=0.0,
                    normalize_before=pre_norm,
                ))

    @classmethod
    def from_config(cls, cfg, in_channels, lang_encoder, mask_classification, extra):
        ret = {}

        ret["lang_encoder"] = lang_encoder
        ret["in_channels"] = in_channels
        ret["mask_classification"] = mask_classification

        enc_cfg = cfg['MODEL']['ENCODER']
        dec_cfg = cfg['MODEL']['DECODER']

        ret["hidden_dim"] = dec_cfg['HIDDEN_DIM']
        ret["dim_proj"] = cfg['MODEL']['DIM_PROJ']
        ret["num_queries"] = dec_cfg['NUM_OBJECT_QUERIES']
        ret["contxt_len"] = cfg['MODEL']['TEXT']['CONTEXT_LENGTH']

        # Transformer parameters:
        ret["nheads"] = dec_cfg['NHEADS']
        ret["dim_feedforward"] = dec_cfg['DIM_FEEDFORWARD']

        assert dec_cfg['DEC_LAYERS'] >= 1
        ret["dec_layers"] = dec_cfg['DEC_LAYERS'] - 1
        ret["pre_norm"] = dec_cfg['PRE_NORM']
        ret["enforce_input_project"] = dec_cfg['ENFORCE_INPUT_PROJ']
        ret["mask_dim"] = enc_cfg['MASK_DIM']
        ret["task_switch"] = extra['task_switch']
        ret["max_spatial_len"] = dec_cfg['MAX_SPATIAL_LEN']

        # attn data struct
        ret["attn_arch"] = cfg['ATTENTION_ARCH']

        return ret

    def forward(self, x, mask_features, ref_features=None, task='seg', extra={}):
        assert len(x) == self.num_feature_levels;
        spatial_extra_flag = 'spatial_query_pos_mask' in extra.keys() or task == 'refimg'
        grounding_extra_flag = 'grounding_tokens' in extra.keys()
        visual_extra_flag = 'visual_query_pos' in extra.keys()
        audio_extra_flag = 'audio_tokens' in extra.keys()
        spatial_memory_flag = 'prev_mask' in extra.keys()
        flags = {"spatial": spatial_extra_flag, "grounding": grounding_extra_flag,
                 "memories_spatial": spatial_memory_flag, "visual": visual_extra_flag, "audio": audio_extra_flag}
        self.attention_data.reset(flags, task, extra)

        src, pos, size_list = prepare_features(x, self.num_feature_levels, self.pe_layer, self.input_proj,
                                               self.level_embed)
        if ref_features != None:
            src_ref, pos_ref, size_list_ref = prepare_features(ref_features[1], self.num_feature_levels, self.pe_layer,
                                                               self.input_proj,
                                                               self.level_embed)
            _, bs_ref, _ = src_ref[0].shape

        _, bs, _ = src[0].shape

        if self.task_switch['spatial'] and spatial_extra_flag:
            _, h, w = extra['spatial_query_pos_mask'][0].shape

            if ref_features:
                mask_1 = (extra['spatial_query_pos_mask'][0]).unsqueeze(1).float()
                mask_1 = F.interpolate(mask_1, ref_features[0].shape[-2:], align_corners=True,
                                       mode='bilinear')
                mask_1 = mask_1.detach()
                num_mask, _, cur_h, cur_w = mask_1.shape
                output = self.m(mask_1)
                indices = output[1]
                positive_pos = indices[output[0] > 0]

                positive_i = torch.floor(positive_pos / (self.win_size * self.win_size))
                positive_j = torch.ceil((positive_pos - positive_i * (self.win_size * self.win_size)) / (
                            self.win_size * self.win_size))
                positive_index = (positive_i + positive_j - 1).int()

                pn_indicator = torch.zeros((cur_h // self.win_size * cur_w // self.win_size))
                pn_indicator[positive_index] = 1

                pos_feature = ref_features[0] * mask_1.int()
                pos_feature = self.pos_embedding(pos_feature)

                neg_feature = ref_features[0] * (~(mask_1.int()))
                neg_feature = self.pos_embedding(neg_feature)

                spatial_query_pos = pos_feature.permute(0, 2, 3, 1).reshape(-1, 512)[pn_indicator == 1].unsqueeze(1)
                spatial_query_neg = neg_feature.permute(0, 2, 3, 1).reshape(-1, 512)[pn_indicator != 1].unsqueeze(1)

            else:
                mask_1 = (extra['spatial_query_pos_mask'][0]).unsqueeze(1).float()
                mask_1 = F.interpolate(mask_1, mask_features[0].shape[-2:], align_corners=True,
                                       mode='bilinear')
                mask_1 = mask_1.detach()
                num_mask, _, cur_h, cur_w = mask_1.shape

                output = self.m(mask_1)
                indices = output[1]
                positive_pos = indices[output[0] > 0]

                positive_i = torch.floor(positive_pos / (self.win_size * self.win_size))
                positive_j = torch.ceil((positive_pos - positive_i * (self.win_size * self.win_size)) / (
                        self.win_size * self.win_size))
                positive_index = (positive_i + positive_j - 1).int()

                pn_indicator = torch.zeros((cur_h // self.win_size * cur_w // self.win_size))
                pn_indicator[positive_index] = 1

                pos_feature = mask_features * mask_1.int()
                pos_feature = self.pos_embedding(pos_feature)

                neg_feature = mask_features * (~(mask_1.int()))
                neg_feature = self.pos_embedding(neg_feature)

                spatial_query_pos = pos_feature.permute(0, 2, 3, 1).reshape(-1, 512)[pn_indicator == 1].unsqueeze(1)
                spatial_query_neg = neg_feature.permute(0, 2, 3, 1).reshape(-1, 512)[pn_indicator != 1].unsqueeze(1)

            bs, _, h, w = mask_features.shape
            mask_features = mask_features.reshape(bs, 512, -1).permute(2, 0, 1)
            spatial_queries = torch.cat((spatial_query_pos, spatial_query_neg), dim=0)

            ##### 直接生成最后的label ########
            for i in range(3):
                _, avg_attn56 = self.extra_cross_atten[i](
                    mask_features, spatial_queries,
                    memory_mask=None,
                    memory_key_padding_mask=None,
                    pos=None, query_pos=None
                )

            ######  利用最终的avg_atten56生成label

            src_spatial_queries_pos = []
            src_spatial_queries_neg = []

            for i in range(len(src)):
                hw, _, dc = src[i].shape
                src_mask_features = src[i].view(size_list[i][0], size_list[i][1], bs, dc)
                src_mask_features = src_mask_features @ self.mask_sptial_embed[i]  ### 7, 7, 1, 512

                if ref_features:
                    hw_ref, _, dc_ref = src_ref[i].shape
                    src_mask_features_ref = src_ref[i].view(size_list[i][0], size_list[i][1], bs_ref, dc_ref)
                    src_mask_features_ref = src_mask_features_ref @ self.mask_sptial_embed[i]

                mask_1 = (extra['spatial_query_pos_mask'][0]).unsqueeze(1).float()
                mask_1 = F.interpolate(mask_1, src_mask_features.shape[:2], align_corners=True,
                                       mode='bilinear')
                mask_1 = mask_1.detach()

                num_mask, _, cur_h, cur_w = mask_1.shape
                output = self.m(mask_1)
                indices = output[1]
                positive_pos = indices[output[0] > 0]

                positive_i = torch.floor(positive_pos / (self.win_size * self.win_size))
                positive_j = torch.ceil((positive_pos - positive_i * (self.win_size * self.win_size)) / (
                        self.win_size * self.win_size))
                positive_index = (positive_i + positive_j - 1).int()

                pn_indicator = torch.zeros((cur_h // self.win_size * cur_w // self.win_size))
                pn_indicator[positive_index] = 1

                if ref_features:
                    pos_feature = src_mask_features_ref.permute(2, 3, 0, 1) * mask_1.int()
                    pos_feature = self.pos_embedding(pos_feature)

                    neg_feature = src_mask_features_ref.permute(2, 3, 0, 1) * (~mask_1.int())
                    neg_feature = self.pos_embedding(neg_feature)
                else:
                    pos_feature = src_mask_features.permute(2, 3, 0, 1) * mask_1.int()
                    pos_feature = self.pos_embedding(pos_feature)

                    neg_feature = src_mask_features.permute(2, 3, 0, 1) * (~mask_1.int())
                    neg_feature = self.pos_embedding(neg_feature)

                src_spatial_query_pos = pos_feature.permute(0, 2, 3, 1).reshape(-1, 512)[pn_indicator == 1]
                src_spatial_query_neg = neg_feature.permute(0, 2, 3, 1).reshape(-1, 512)[pn_indicator != 1]

                src_spatial_queries_pos += [src_spatial_query_pos]
                src_spatial_queries_neg += [src_spatial_query_neg]

            src_spatial_queries = [torch.cat([x, y], dim=0) for x, y in
                                        zip(src_spatial_queries_pos, src_spatial_queries_neg)]

            pos_neg_indicator = [x.shape[0] for x, y in zip(src_spatial_queries_pos, src_spatial_queries_neg)]  #####[1, 512] 指示哪些是pos,哪些是neg

            if 'refimg' in task:
                output_refimg = {}
                output_refimg['visual_query_pos'] = spatial_query_pos
                output_refimg['visual_query_neg'] = spatial_query_neg
                output_refimg['src_visual_queries'] = src_spatial_queries
                return output_refimg

        if self.task_switch['visual'] and visual_extra_flag:
            visual_query_pos = extra['visual_query_pos']
            visual_query_neg = extra['visual_query_neg']
            src_spatial_queries = extra['src_visual_queries']

        avg_atten_list = {}
        for i in range(self.num_layers):
            level_index = i % self.num_feature_levels
            spatial_tokens = src_spatial_queries[level_index]  ###  179, 512
            output = src[level_index]

            if ref_features:
                spatial_tokens = spatial_tokens.reshape(-1, 1, 512)

            _spatial_tokens = spatial_tokens.detach().clone()
            self.attention_data.set('tokens_spatial', 'tokens', spatial_tokens, _spatial_tokens)

            _, avg_attn_level = self.transformer_cross_attention_layers[i](
                output, _spatial_tokens,
                memory_mask=None,
                memory_key_padding_mask=None,
                pos=None, query_pos=None
            )
            avg_atten_list[level_index] = avg_attn_level


        results = self.forward_prediction_heads(avg_atten_list, avg_attn56, pos_neg_indicator, pn_indicator)
        results["predictions_pos_spatial"] = spatial_query_pos.transpose(0, 1) if spatial_extra_flag else None
        results["predictions_neg_spatial"] = spatial_query_neg.transpose(0, 1) if spatial_extra_flag else None
        results["predictions_pos_visual"] = visual_query_pos.transpose(0, 1) if visual_extra_flag else None
        results["predictions_neg_visual"] = visual_query_neg.transpose(0, 1) if visual_extra_flag else None

        output = results
        if self.task_switch['spatial'] and spatial_extra_flag:
            temp = self.attention_data.update_spatial_results(results, ref_features)
            output['prev_mask'] = temp['prev_mask']
        return output

    def forward_prediction_heads(self, avg_atten_list, avg_attn56, pos_neg_indicator, pn_indicator):
        ######多个尺度分别生成label  #########
        for i in range(len(avg_atten_list)):
            atten = avg_atten_list[i] * pos_neg_indicator[i]



@register_decoder
def get_masked_transformer_decoder(cfg, in_channels, lang_encoder, mask_classification, extra):
    return MultiScaleMaskedTransformerDecoder(cfg, in_channels, lang_encoder, mask_classification, extra)