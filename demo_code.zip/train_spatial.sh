script_path=/data1/Segment-Everything-Everywhere-All-At-Once-main_v3/demo_code/
cd $script_path

method='/data1/Segment-Everything-Everywhere-All-At-Once-main_v3/demo_code/train_ref_img_1'

python -m torch.distributed.launch \
    --nproc_per_node=$num \
    $method.py