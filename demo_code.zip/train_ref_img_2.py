import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

try:
    # ignore ShapelyDeprecationWarning from fvcore
    from shapely.errors import ShapelyDeprecationWarning
    import warnings
    warnings.filterwarnings('ignore', category=ShapelyDeprecationWarning)
except:
    pass

import copy
import itertools
import logging
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
from collections import OrderedDict
from typing import Any, Dict, List, Set

import torch
from torch.utils.tensorboard import SummaryWriter
import detectron2.utils.comm as comm
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.config import get_cfg
from detectron2.data import MetadataCatalog, build_detection_train_loader, build_detection_test_loader
from detectron2.engine import (
    DefaultTrainer,
    default_argument_parser,
    default_setup,
    launch,
)
from detectron2.evaluation import (
    COCOEvaluator,
    COCOPanopticEvaluator,
    DatasetEvaluators,
    SemSegEvaluator,
    verify_results,
)
from detectron2.projects.deeplab import add_deeplab_config, build_lr_scheduler
from detectron2.solver.build import maybe_add_gradient_clipping
from detectron2.utils.logger import setup_logger
import argparse
# MaskFormer
from dataset.maskfromer_panoptic_dataset_mapper import MaskFormerPanopticDatasetMapperTrain, MaskFormerPanopticDatasetMapperTest
from dataset.mask_former_semantic_dataset_mapper import MaskFormerSemanticDatasetMapper
from configs.config import add_maskformer2_config
from dataset.register_coco_panptic_anno import register_all_coco_panoptic_annos_sem_seg

from xdecoder.BaseModel import BaseModel
from xdecoder import build_model
from utils.distributed import init_distributed
from utils.arguments import load_opt_from_config_files
from torch.optim import SGD
from utils.constants import COCO_PANOPTIC_CLASSES
from utils.util import count_params, init_log, AverageMeter
import logging
import yaml
import numpy as np
from evaluate import evaluate
from classes import CLASSES
from detectron2.engine import DefaultTrainer
from torch.optim import AdamW
from utils.util import count_params, AverageMeter, intersectionAndUnion, init_log
from collections import defaultdict
from PIL import Image
import imgviz
from detectron2.engine import (
    DefaultTrainer,
    default_argument_parser,
    default_setup,
    hooks,
    launch,
    create_ddp_model,
    AMPTrainer,
    SimpleTrainer
)
import torch.distributed as dist

import os

# os.environ["CUDA_VISIBLE_DEVICES"] = "1"


def save_colored_mask(mask, save_path):
    lbl_pil = Image.fromarray(mask.astype(np.uint8), mode="P")
    colormap = imgviz.label_colormap()
    lbl_pil.putpalette(colormap.flatten())
    lbl_pil.save(save_path)

#######  backbone and decoder using pretrained ckpt and both without freezing  #####
def setup(args):
    """
    Create configs and perform basic setups.
    """
    cfg = get_cfg()
    # for poly lr schedule
    add_deeplab_config(cfg)
    add_maskformer2_config(cfg)
    cfg.merge_from_file(
        "/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/configs/maskformer2_R50_bs16_50ep.yaml")
    # cfg.merge_from_list(args.opts)
    cfg.freeze()
    default_setup(cfg, args)
    # Setup logger for "mask_former" module
    setup_logger(output=cfg.OUTPUT_DIR, distributed_rank=comm.get_rank(), name="mask2former")
    return cfg

def main():
    parser = argparse.ArgumentParser('SEEM Demo', add_help=False)
    parser.add_argument('--conf_files', default="configs/seem/seem_focall_lang.yaml", metavar="FILE",
                        help='path to config file', )
    parser.add_argument('--yaml_file', default="configs/coco.yaml")
    parser.add_argument('--save_path', default="./save_refimg_4/")
    # parser.add_argument("--local-rank", default=os.getenv('LOCAL_RANK', -1), type=int)

    args = parser.parse_args()

    #############  读取模型文件并配置  ######################
    opt = load_opt_from_config_files(args.conf_files)
    opt = init_distributed(opt)

    # if args.local_rank != -1:
    #     torch.cuda.set_device(args.local_rank)
    #     device = torch.device("cuda", args.local_rank)
    #     torch.distributed.init_process_group(backend="nccl", init_method='env://')


    if 'focalt' in args.conf_files:
        pretrained_pth = os.path.join("seem_focalt_v2.pt")
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focalt_v2.pt"))
    elif 'focal' in args.conf_files:
        pretrained_pth = "/data1/seem_focall_v1.pt"
        if not os.path.exists(pretrained_pth):
            os.system("wget {}".format("https://huggingface.co/xdecoder/SEEM/resolve/main/seem_focall_v1.pt"))

    model = BaseModel(opt, build_model(opt)).from_pretrained(pretrained_pth).cuda()
    model.model.sem_seg_head.predictor.lang_encoder.get_text_embeddings(COCO_PANOPTIC_CLASSES + ["background"],
                                                                        is_eval=True)

    ##########  设置训练模式，通用分割任务  ############################################################
    # model.task_switch['visual'] = False
    model.model.task_switch['spatial'] = True
    model.model.task_switch['visual'] = False
    model.model.task_switch['grounding'] = False
    model.model.task_switch['audio'] = False


    ##########  分布式训练  #######################################################################
    # model.to(device)
    # num_gpus = torch.cuda.device_count()
    # if num_gpus > 1:
    #     print('use {} gpus!'.format(num_gpus))
    #     model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank],
    #                                                       output_device=args.local_rank)


    #############  读取训练文件并配置  ####################
    cfg_yaml = yaml.load(open(args.yaml_file, "r"), Loader=yaml.Loader)
    optimizer = AdamW([param for name, param in model.named_parameters()], 2e-5, weight_decay=1e-4)

    logger = init_log('global', logging.INFO)
    writer = SummaryWriter(args.save_path)
    logger.propagate = 0

    previous_best = 0.0
    epoch = -1
    rank = 0

    cfg = setup(args)

    register_all_coco_panoptic_annos_sem_seg()

    mapper_train = MaskFormerPanopticDatasetMapperTrain(cfg, True)
    mapper_test = MaskFormerPanopticDatasetMapperTest(cfg, False)

    train_loader = build_detection_train_loader(cfg, mapper=mapper_train)

    val_dataset_name = "coco_2017_val_panoptic_with_sem_seg"
    val_loader = build_detection_test_loader(cfg, mapper=mapper_test, dataset_name=val_dataset_name)

    evaluator_list = []
    evaluator_type = MetadataCatalog.get(val_dataset_name).evaluator_type
    output_folder = os.path.join(cfg.OUTPUT_DIR, "inference")

    if evaluator_type == "coco_panoptic_seg" and cfg.MODEL.MASK_FORMER.TEST.SEMANTIC_ON:
        evaluator_list.append(SemSegEvaluator(val_dataset_name, distributed=True, output_dir=output_folder))
    evaluator = evaluator_list[0]

    total_iters = len(train_loader) * 30
    previous_best = 0.0

    # if os.path.exists(os.path.join(args.save_path, 'latest.pth')):
    #     checkpoint = torch.load(os.path.join(args.save_path, 'latest.pth'))
    #     model.load_state_dict(checkpoint['model'])
    #     optimizer.load_state_dict(checkpoint['optimizer'])
    #     epoch = checkpoint['epoch']
    #     previous_best = checkpoint['previous_best']

    # checkpoint = torch.load(os.path.join(args.save_path, '63999_latest.pth'))
    # model.load_state_dict(checkpoint['model'])
    # print(63999)

    # for epoch in range(epoch + 1, cfg_yaml['epochs']):
    #     logger.info('===========> Epoch: {:}, LR: {:.5f}, Previous best: {:.2f}'.format(
    #             epoch, optimizer.param_groups[0]['lr'], previous_best))
    #
    #     total_loss = AverageMeter()
    #
    #     for i, data in enumerate(train_loader):
    #         model.train()
    #
    #         loss = model.model(data)
    #         losses = sum(loss.values()) / 4
    #         losses.backward()
    #         # torch.distributed.barrier()
    #
    #         # optimizer.zero_grad()
    #         # optimizer.step()
    #         print(i)
    #         if (i + 1) % 4 == 0:
    #             optimizer.step()  # 根据累计到batch_size个梯度，进行网络参数更新
    #             optimizer.zero_grad()  # 梯度清0
    #
    #         iters = epoch * len(train_loader) + i
    #
    #         total_loss.update(losses.item())
    #
    #         writer.add_scalar('train/loss_all', losses.item(), iters)
    #
    #         # if (i % (len(train_loader) // 8) == 0):
    #         if ((i+1) % 4) == 0:
    #             logger.info(
    #                 'Iters: {:}, Total loss: {:.3f}'.format(i, total_loss.avg))
    #
    #         if rank == 0 and (i + 1) % 7000 == 0:
    #             checkpoint = {
    #                 'model': model.state_dict(),
    #                 'optimizer': optimizer.state_dict(),
    #                 'epoch': epoch,
    #                 'previous_best': previous_best,
    #             }
    #             torch.save(checkpoint, os.path.join(args.save_path, '{}_latest.pth'.format(i+15000)))
    #             # if is_best:
    #             #     torch.save(checkpoint, os.path.join(args.save_path, 'best.pth'))

        # if ((i+1) % 300) == 0:
    model.eval()
    with torch.no_grad():
        iou_arr = np.zeros(133)
        count_arr = np.zeros(133)
        for idx, input in enumerate(val_loader):
            pred = model(input, mode='interactive')
            print(pred)
            print(idx)
            ##### 取最后一个维度的作为最后的预测iou
            tar_class = input[0]["groundings"]["hash"]
            for i, iou_ in enumerate(pred):
                max_iou = iou_['mask_iou'][-1]

                # dist.all_reduce(torch.tensor(max_iou).cuda())

                iou_arr[tar_class[i]] += max_iou
                count_arr[tar_class[i]] += 1

        miou = iou_arr / (count_arr + 1e-7)
        print("segment iou is:{}".format(miou))

                    # is_best = mIOU > previous_best
                    # previous_best = max(mIOU, previous_best)
            # if rank == 0 and (i % 5000) == 0:
            #     checkpoint = {
            #         'model': model.state_dict(),
            #         'optimizer': optimizer.state_dict(),
            #         'epoch': epoch,
            #         'previous_best': previous_best,
            #     }
            #     torch.save(checkpoint, os.path.join(args.save_path, '{}_latest.pth'.format(i)))
            #     # if is_best:
            #     #     torch.save(checkpoint, os.path.join(args.save_path, 'best.pth'))

if __name__ == "__main__":
    main()



