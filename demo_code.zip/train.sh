#!/bin/bash
now=$(date +"%Y%m%d_%H%M%S")

# modify these augments if you want to try other datasets, splits or methods
# dataset: ['pascal', 'cityscapes', 'coco']
# method: ['unimatch', 'fixmatch', 'supervised']
# exp: just for specifying the 'save_path'
# split: ['92', '1_16', 'u2pl_1_16', ...]. Please check directory './splits/$dataset' for concrete splits
#export PATH=/data1/Segment-Everything-Everywhere-All-At-Once-main/:$PATH
script_path=/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/
cd $script_path

dataset='coco'
method='/data1/Segment-Everything-Everywhere-All-At-Once-main/demo_code/train_ref_img'
num=2

#mkdir -p $save_path

python -m torch.distributed.launch \
    --nproc_per_node=$num \
    $method.py