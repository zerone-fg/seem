sudo apt update
sudo apt install ffmpeg
pip install -r requirements.txt
python3 app.py
