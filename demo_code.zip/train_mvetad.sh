#!/bin/bash
now=$(date +"%Y%m%d_%H%M%S")

script_path=/data1/Mvtecad_main/demo_code/
cd $script_path

method='/data1/Mvtecad_main/demo_code/train_mvetad_1'

#mkdir -p $save_path
#CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node=4 --use_env train_mvetad.py
python $method.py